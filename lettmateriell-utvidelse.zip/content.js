// Runs on product pages in the wholesalers' and shops' web sites. Reads the
// product's numbers, asks LettMateriell what it costs at the user's wholesalers
// and shows that in a small box in the corner.
(() => {
  const host = location.hostname.replace(/^www\./, "");
  // On the wholesalers' sites the price shown is the company's own net price:
  // it is never saved as a shop price.
  const WHOLESALER_SITE =
    /(^|\.)(ahlsell|dahl|onninen|solar|solarnorge|heidenreich|berggardamundsen|baelgros|elektroimportoren|sonepar)\.no$/
      .test(host);
  const SITE = globalThis.LM_CONFIG.siteUrl;

  let lastKey = "";
  let hostEl = null;
  // Wholesalers switched off in the extension's menu (their sites, e.g. «onninen.no»).
  let off = new Set();

  /** The page's visible text is read once per check (it makes the browser lay out the page). */
  function readProduct(visibleText) {
    const ld = LMExtract.fromJsonLd(
      [...document.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? ""),
    );
    const microGtin = LMExtract.digits(document.querySelector('[itemprop^="gtin"]')?.getAttribute("content"));
    const micro = {
      gtin: LMExtract.validGtin(microGtin) ? microGtin : null,
      price: LMExtract.parsePrice(document.querySelector('[itemprop="price"]')?.getAttribute("content") ?? ""),
      name: document.querySelector('h1')?.textContent?.trim() || null,
    };
    const visible = LMExtract.fromText(visibleText.slice(0, 200_000));
    // Some shops keep the numbers in a folded or hidden section (Elektroimportøren
    // does); then the page's whole text is read as well.
    const folded = visible.elNr || visible.nrfNr || visible.gtin
      ? {}
      : LMExtract.fromText(LMReaders.textOf(document.body).replace(/\s+/g, " ").slice(0, 500_000));
    const scripts = /(^|\.)onninen\.no$/.test(host)
      ? [...document.querySelectorAll("script:not([src])")].map((s) => s.textContent ?? "").join("\n")
      : "";
    const site = LMExtract.fromSite(host, location.pathname, visibleText, scripts);
    return LMExtract.merge(site, visible, folded, ld, micro);
  }

  // After the extension is reloaded, pages already open lose contact with it:
  // sendMessage then throws («Extension context invalidated») until the page is reloaded.
  let disconnected = false;
  const send = async (message) => {
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (e) {
      const error = String(e?.message ?? e);
      if (/context invalidated|receiving end does not exist/i.test(error) || !chrome.runtime?.id) disconnected = true;
      return { error };
    }
  };

  // On a wholesaler's site: the prices shown to the signed-in customer could be saved
  // for their company, but only with a checked reader (none yet, so nothing is saved).
  const reader = WHOLESALER_SITE ? LMReaders.readerFor(host) : null;
  let lastCapture = "";
  // The product whose price was just saved for the first time here: its bubble opens by itself.
  let openFor = "";

  /** "none": no reader here; "saved"/"same": the price was sent (now/before); "empty": not on the page (yet). */
  async function capture() {
    if (!reader) return "none";
    let items;
    try {
      items = reader(document);
    } catch {
      return "none"; // a changed page must not break the box
    }
    if (!items.length) return "empty";
    const signature = location.href + JSON.stringify(items);
    if (signature === lastCapture) return "same";
    lastCapture = signature;
    const res = await send({ type: "recordWholesaler", site: host, url: location.origin + location.pathname, items });
    if (res?.first) openFor = `${items[0].el_nr ?? null}|${items[0].nrf_nr ?? null}|${items[0].gtin ?? null}`;
    return "saved";
  }

  // Lists of products (search results, category pages, variant tables, Solar's carousels): the
  // price on each product is saved, signed in and when saving prices is on, with a link to that
  // product's own page where the list has one. Solar's cards also fill the shared catalog with
  // their links. Read from what the page shows, whenever it changes; each product is sent once
  // per page load, at most 300 per page.
  const listReader = LMReaders.listReaderFor(host);
  const linkCards = /(^|\.)solarnorge\.no$/.test(host);
  const sentCards = new Set();
  const sentPrices = new Set();
  let cardTimer = null;
  const keyOf = (c) => c.el_nr ?? c.nrf_nr ?? c.gtin;

  function scanCards() {
    if (!listReader || off.has(host) || disconnected || sentPrices.size >= 300) return;
    let cards;
    try {
      cards = listReader(document);
    } catch {
      return;
    }
    // Sent once per product per page, even when the price appears after the link was sent. A row
    // without its own link (Ahlsell's variants) gets the page's address, so it is kept only on a
    // product page: opened from a search (2026-11-18), it would store «…/search/» as the link.
    const onProductPage = LMExtract.isProductPage(host, location.pathname);
    const priced = cards
      .filter((c) => c.price && keyOf(c) && !sentPrices.has(keyOf(c)) && (c.url || onProductPage))
      .slice(0, 100);
    if (priced.length) {
      for (const c of priced) sentPrices.add(keyOf(c));
      const items = priced.map((c) => ({
        el_nr: c.el_nr ?? null, nrf_nr: c.nrf_nr ?? null, gtin: c.gtin ?? null, name: c.name ?? null,
        price: c.price, unit: c.unit, ...(c.url ? { url: c.url } : {}),
      }));
      send({ type: "recordWholesaler", list: true, site: host, url: location.origin + location.pathname, items }).then((res) => {
        if (res?.error) for (const c of priced) sentPrices.delete(keyOf(c));
      });
    }
    if (!linkCards || sentCards.size >= 300) return;
    const fresh = cards.filter((c) => c.el_nr && !sentCards.has(c.el_nr)).slice(0, 60)
      .map((c) => ({ el_nr: c.el_nr, gtin: c.gtin, url: c.url, name: c.name }));
    if (!fresh.length) return;
    for (const c of fresh) sentCards.add(c.el_nr);
    // Not sent (the extension was asleep or offline): tried again on the next change.
    send({ type: "seenLinks", site: host, items: fresh }).then((res) => {
      if (res?.error) for (const c of fresh) sentCards.delete(c.el_nr);
    });
  }

  // At most one look every 1.5 s while the page changes. (Waiting for the page to be still could
  // wait forever: Solar's carousels and stock lines keep changing it.)
  function scheduleCards() {
    if (!listReader || cardTimer) return;
    cardTimer = setTimeout(() => {
      cardTimer = null;
      scanCards();
    }, 1500);
  }

  // Work is done once per page: until the product (and its price, where read) is found.
  let pageDone = false;

  async function check() {
    if (document.visibilityState !== "visible") return;
    // Switched off in the menu: nothing at all on this wholesaler's site.
    if (off.has(host)) return remove();
    // Category and search pages at the wholesalers: no single product to show.
    if (WHOLESALER_SITE && !LMExtract.isProductPage(host, location.pathname)) {
      pageDone = true;
      return remove();
    }
    const p = readProduct(document.body?.innerText ?? "");
    if (!p.elNr && !p.nrfNr && !p.gtin) {
      // Maybe still loading: tried again on changes. At a wholesaler the panel is there from the start.
      if (!WHOLESALER_SITE) return remove();
      if (tries >= MAX_TRIES) return renderNote("Fant ikke varenummeret på denne siden.");
      return renderLoading("Leser varen …", null);
    }
    const key = `${location.href}|${p.elNr}|${p.nrfNr}|${p.gtin}`;
    // A new product at a wholesaler: the panel shows that its prices are being fetched.
    if (WHOLESALER_SITE && key !== lastKey) renderLoading("Henter priser …", p);
    const captured = await capture();
    if (captured !== "empty") pageDone = true;
    // Same product as last time: only a newly saved price is a reason to ask again.
    if (key === lastKey && captured !== "saved") return;
    const firstTime = key !== lastKey;
    lastKey = key;
    // The EL number of an electrical product opened at a wholesaler goes to LettMateriell (once per number).
    const breadcrumb = [...document.querySelectorAll('nav.breadcrumb a, nav[aria-label="Brødsmule"] a')]
      .map((a) => a.getAttribute("href"));
    if (firstTime && WHOLESALER_SITE && p.elNr && p.gtin && LMExtract.isElektro(host, location.pathname, breadcrumb)) {
      send({
        type: "viewed",
        product: { site: host, url: location.origin + location.pathname, elNr: p.elNr, nrfNr: p.nrfNr, gtin: p.gtin, name: p.name },
      });
    }
    const shopPrice = WHOLESALER_SITE ? null : p.price;
    const res = await send({
      type: "lookup",
      product: { elNr: p.elNr, nrfNr: p.nrfNr, gtin: p.gtin },
      // Shop prices are only shown in shops; no need to ask for them at a wholesaler.
      shops: !WHOLESALER_SITE,
    });
    if (key !== lastKey) return; // the page changed while waiting
    if (firstTime && res?.signedIn && shopPrice) {
      send({
        type: "record",
        product: { shop: host, url: location.origin + location.pathname, ...p, price: shopPrice },
      });
    }
    render(p, res, shopPrice);
  }

  const kr = LMPrices.formatKr;

  function median(values) {
    const v = [...values].sort((a, b) => a - b);
    const m = Math.floor(v.length / 2);
    return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2;
  }

  function remove() {
    hostEl?.remove();
    hostEl = null;
    dockedNow = false;
    setPush(false);
  }

  // At a wholesaler the panel is part of the page: a dark card in the bottom right corner, as tall as what it
  // shows, open on every product page. The page makes room for it in a middle-sized window; a wide
  // one has room in its margin already, and in a narrow one it lies over the page. Pressing › folds
  // it into a tab on the edge for the rest of this page; a new page load opens it again.
  const PANEL_W = 280;
  let folded = false;
  let redraw = null;

  function setPush(on) {
    let s = document.getElementById("lettmateriell-push");
    const want = on && window.innerWidth >= 1000 && window.innerWidth < 1600;
    if (!want) return s?.remove();
    if (!s) {
      s = document.createElement("style");
      s.id = "lettmateriell-push";
      s.textContent = `html { margin-right: ${PANEL_W}px !important; }`;
      (document.head ?? document.documentElement).append(s);
    }
  }

  /** Puts the box on the page: "dock" (the column at a wholesaler), "tab" (folded) or "float" (in shops). */
  function mount(box, mode) {
    hostEl?.remove();
    hostEl = document.createElement("div");
    hostEl.style.cssText = {
      dock: `position:fixed;bottom:16px;right:0;width:${PANEL_W}px;z-index:2147483647;`,
      tab: "position:fixed;bottom:16px;right:0;z-index:2147483647;",
      float: "position:fixed;right:16px;bottom:16px;z-index:2147483647;",
    }[mode];
    // A closed shadow root: the page's scripts and styles cannot reach the prices.
    const root = hostEl.attachShadow({ mode: "closed" });
    root.append(el("style", {}, STYLE), box);
    document.documentElement.append(hostEl);
    dockedNow = mode === "dock";
    setPush(dockedNow);
  }
  let dockedNow = false;
  // A narrow window: the panel lies over the page instead of pushing it.
  window.addEventListener("resize", () => setPush(dockedNow && !!hostEl));

  function foldButton() {
    return el("button", { class: "icon", title: "Skjul LettMateriell", onclick: () => {
      folded = true;
      redraw?.();
    } }, "›");
  }

  /** The folded panel: a tab on the right edge that opens it again. */
  function mountTab(title) {
    mount(el("button", { class: "tab", title, onclick: () => {
      folded = false;
      redraw?.();
    } }, "‹ LettMateriell"), "tab");
  }

  /** The docked panel's top: the name, a line that says it all, and › to fold it. */
  function dockHead(headline, good = false) {
    return el("div", { class: "head" },
      el("div", {},
        el("div", { class: "brand" }, "LettMateriell"),
        headline ? el("strong", { class: good ? "headline good" : "headline" }, headline) : null),
      el("span", { class: "buttons" }, foldButton()));
  }

  /** At a wholesaler, while the product is read or its prices are fetched: shown in the panel. */
  function renderLoading(text, p) {
    redraw = () => renderLoading(text, p);
    if (folded) return mountTab(text);
    const box = el("div", { class: "box docked" }, dockHead(null));
    if (p?.name) box.append(el("div", { class: "name" }, p.name));
    if (p) box.append(...[productNumbers(p)].filter(Boolean));
    box.append(el("div", { class: "loading" }, el("span", { class: "spinner" }), text),
      el("div", { class: "skel" }), el("div", { class: "skel short" }), el("div", { class: "skel" }));
    mount(box, "dock");
  }

  /** At a wholesaler, when there is nothing to show but a short note. */
  function renderNote(text, button = null) {
    redraw = () => renderNote(text, button);
    if (folded) return mountTab(text);
    mount(el("div", { class: "box docked" }, dockHead(null), el("p", { class: "muted" }, text), button), "dock");
  }

  function el(tag, attrs = {}, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === "onclick") e.addEventListener("click", v);
      else e.setAttribute(k, v);
    }
    for (const c of children) if (c != null) e.append(c);
    return e;
  }

  /** «EL 1241010 · NRF … · EAN …»: the numbers read on the page, under the product name. */
  function productNumbers(p) {
    const parts = [
      p.elNr && `EL ${p.elNr}`,
      p.nrfNr && `NRF ${p.nrfNr}`,
      p.gtin && `EAN ${p.gtin}`,
    ].filter(Boolean);
    return parts.length ? el("div", { class: "numbers" }, parts.join(" · ")) : null;
  }

  // Wholesaler (slug) → its site, and site → the name shown.
  const SLUG_SITE = {
    "ahlsell": "ahlsell.no",
    "ahlsell-vvs": "ahlsell.no",
    "brodrene-dahl": "dahl.no",
    "onninen": "onninen.no",
    "solar": "solarnorge.no",
    "heidenreich": "heidenreich.no",
    "berggard-amundsen": "berggardamundsen.no",
    "elektroimportoren": "elektroimportoren.no",
  };
  const SITE_NAME = {
    "ahlsell.no": "Ahlsell",
    "dahl.no": "Brødrene Dahl",
    "onninen.no": "Onninen",
    "solarnorge.no": "Solar",
    "heidenreich.no": "Heidenreich",
    "berggardamundsen.no": "Berggård Amundsen",
    "elektroimportoren.no": "Elektroimportøren",
  };

  /** The wholesaler slugs of the site we are on (Ahlsell has two). */
  function siteSlugs() {
    const site = host.replace(/^.*?([a-z0-9-]+\.no)$/, "$1");
    return {
      "ahlsell.no": ["ahlsell", "ahlsell-vvs"],
      "dahl.no": ["brodrene-dahl"],
      "onninen.no": ["onninen"],
      "solarnorge.no": ["solar"],
      "heidenreich.no": ["heidenreich"],
      "berggardamundsen.no": ["berggard-amundsen"],
      "elektroimportoren.no": ["elektroimportoren"],
    }[site] ?? [];
  }

  /** Whether a saved item's key «el|nrf|gtin» is the product read on the page (any number in common). */
  function sameProduct(key, p) {
    const [el, nrf, gtin] = key.split("|");
    return (el !== "null" && el === p.elNr) || (nrf !== "null" && nrf === p.nrfNr) || (gtin !== "null" && gtin === p.gtin);
  }

  // The user's own open/closed choice for the product shown; null until they press ▾/▴.
  let chosen = null;
  let chosenFor = "";

  function render(p, res, shopPrice) {
    const docked = WHOLESALER_SITE;
    if (docked) redraw = () => render(p, res, shopPrice);
    else remove();
    // No answer: the panel (or the round button) stays, so it never just vanishes. When the
    // extension was reloaded, pressing it reloads the page to reconnect.
    const retry = () => (disconnected ? location.reload() : (lastKey = "", pageDone = false, tries = 0, schedule(0)));
    if (res?.error && docked) {
      return renderNote(
        disconnected ? "LettMateriell ble oppdatert. Last siden på nytt for å se prisene." : "LettMateriell svarer ikke akkurat nå.",
        el("button", { class: "action", onclick: retry }, disconnected ? "Last siden på nytt" : "Prøv igjen"),
      );
    }
    if (res?.error) {
      hostEl = document.createElement("div");
      hostEl.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;";
      const root = hostEl.attachShadow({ mode: "closed" });
      root.append(el("style", {}, STYLE));
      const button = el("button", {
        class: "icon",
        title: disconnected ? "LettMateriell ble oppdatert: trykk for å laste siden på nytt" : "LettMateriell svarer ikke akkurat nå",
        onclick: retry,
      }, disconnected ? "↻" : "▲");
      root.append(el("div", { class: "box collapsed bare" }, button));
      document.documentElement.append(hostEl);
      return;
    }
    // Wholesalers the user has switched off in the menu are left out. One price per wholesaler: a
    // current one, else an old one (prices.js). Old prices are shown at the bottom, greyed, and do not
    // count for «billigst», the saving or «Du sparer».
    const offers = LMPrices.pickOffers((res?.offers ?? []).filter((o) => !off.has(SLUG_SITE[o.wholesaler])), Date.now());
    const fresh = offers.filter((o) => !o.old);
    const old = offers.filter((o) => o.old);
    // In a shop, nothing to tell about a product that is not in the user's prices.
    if (res?.signedIn && offers.length === 0 && !WHOLESALER_SITE) return;

    // The bubble opens by itself when at least two wholesalers have a current price to compare, and
    // when the price on this page was just saved for the first time (so the user sees it was saved);
    // otherwise it stays small and can be opened with ▴.
    const productKey = `${p.elNr}|${p.nrfNr}|${p.gtin}`;
    if (chosenFor !== productKey) {
      chosen = null;
      chosenFor = productKey;
    }
    const firstSaved = openFor !== "" && sameProduct(openFor, p);
    // At a wholesaler the panel is open unless the user folded it.
    const collapsed = docked ? false : chosen ?? (firstSaved ? false : fresh.length < 2);

    const box = el("div", { class: docked ? "box docked" : collapsed ? "box collapsed" : "box" });
    // The bubble cannot be removed, only made small (▾) and opened again (▴).
    const toggle = el("button", { class: "icon", title: collapsed ? "Vis" : "Gjør mindre", onclick: () => {
      chosen = !collapsed;
      render(p, res, shopPrice);
    } }, collapsed ? "▴" : "▾");

    const here = siteSlugs();
    // The product at other wholesalers, as seen by any company: a link, but no price.
    const links = (res?.links ?? []).filter((l) => !off.has(l.site));
    const urlAt = (o) => o.product_url ?? links.find((l) => l.site === SLUG_SITE[o.wholesaler])?.url ?? null;
    const pricedSites = new Set(offers.map((o) => SLUG_SITE[o.wholesaler]));
    const otherLinks = links.filter((l) => !pricedSites.has(l.site) && l.site !== host);
    const linkRow = (l) =>
      el("li", { class: "link-only" },
        el("span", {}, el("a", { href: l.url, target: "_blank", rel: "noopener" }, SITE_NAME[l.site] ?? l.site)),
        el("span", { class: "muted" }, "Se varen →"));
    // One price in the list: the wholesaler (linked when it is another one), the date it is from, and
    // the price per unit. An old price is greyed and says «gammel pris»; a price with no known date is
    // greyed and says «dato ukjent» (it is not called old, since its age is not known).
    const priceRow = (o) => {
      const price = Number(o.net_per_measure_unit);
      const isHere = here.includes(o.wholesaler);
      const cls = o.old ? "old" : [price === bestPrice ? "best" : "", isHere ? "here" : ""].join(" ").trim();
      return el("li", { class: cls },
        el("span", {},
          el("span", {},
            // Each name links to the product at that wholesaler.
            urlAt(o) && !isHere
              ? el("a", { href: urlAt(o), target: "_blank", rel: "noopener" }, o.wholesaler_name.trim())
              : o.wholesaler_name.trim(),
            isHere ? el("span", { class: "tag" }, "her") : null,
            o.old && o.age !== null ? el("span", { class: "tag old-tag" }, "gammel pris") : null),
          el("small", { class: "when" }, LMPrices.priceDate(o))),
        el("span", { class: "num" }, LMPrices.formatPerUnit(price, LMPrices.unitName(o.measure_unit))));
    };
    // The cheapest current price: the one everything else is compared with.
    const best = fresh[0];
    // The current price here, if any (an old price here is shown in the list instead).
    const hereOffer = fresh.find((o) => here.includes(o.wholesaler));
    // The wholesaler we are on is always in the list, also before the company has its price.
    const hereSite = host.replace(/^.*?([a-z0-9-]+\.no)$/, "$1");
    const hereRow = WHOLESALER_SITE && !offers.some((o) => here.includes(o.wholesaler)) && SITE_NAME[hereSite]
      ? el("li", { class: "here link-only" },
        el("span", {}, SITE_NAME[hereSite], el("span", { class: "tag" }, "her")),
        el("span", { class: "muted" }, "ingen pris lagret"))
      : null;
    const bestPrice = best ? Number(best.net_per_measure_unit) : null;

    // Fewer than two current prices: nothing to compare, so the small bubble is only the ▴ to open it.
    const comparing = fresh.length >= 2;
    if (collapsed && !comparing) {
      box.classList.add("bare");
      toggle.textContent = "▲";
      toggle.title = "Vis LettMateriell";
      box.append(toggle);
      return mount(box, "float");
    }

    // One line that says it all, also when the bubble is made small.
    let headline = "LettMateriell";
    if (!comparing) {
      headline = docked
        ? (res?.signedIn ? (offers.length ? "Prisene dine" : "Ingen priser ennå") : "Logg inn for å se prisene")
        : (res?.signedIn ? "LettMateriell" : "LettMateriell: logg inn");
    }
    else if (hereOffer && Number(hereOffer.net_per_measure_unit) === bestPrice) headline = "Billigst her ✓";
    else if (hereOffer) {
      const save = Number(hereOffer.net_per_measure_unit) - bestPrice;
      headline = `${LMPrices.formatPerUnit(save, LMPrices.unitName(best.measure_unit))} billigere hos ${best.wholesaler_name.trim()}`;
    } else headline = `Billigst hos ${best.wholesaler_name.trim()}: ${LMPrices.formatPerUnit(bestPrice, LMPrices.unitName(best.measure_unit))}`;
    const good = comparing && (!hereOffer || Number(hereOffer.net_per_measure_unit) === bestPrice);
    if (docked && folded) return mountTab(headline);
    box.append(docked ? dockHead(headline, good) : el("div", { class: "head" },
      el("strong", { class: good ? "headline good" : "headline" }, headline),
      el("span", { class: "buttons" }, toggle)));

    if (!collapsed) {
      if (!res?.signedIn) {
        box.append(el("p", { class: "muted" }, "Logg inn i utvidelsen (klikk på LettMateriell-ikonet øverst) for å se prisene dine."));
      } else if (!offers.length) {
        if (p.name) box.append(el("div", { class: "name" }, p.name), ...[productNumbers(p)].filter(Boolean));
        box.append(el("p", { class: "muted" }, "Firmaet ditt har ikke sett prisen på denne varen hos noen grossist ennå."));
        if (otherLinks.length || hereRow) {
          const list = el("ul");
          if (hereRow) list.append(hereRow);
          for (const l of otherLinks) list.append(linkRow(l));
          box.append(el("div", { class: "label" }, otherLinks.length ? "Varen finnes hos" : "Grossisten"), list);
        }
      } else {
        box.append(el("div", { class: "name" }, (best ?? offers[0]).product_name), ...[productNumbers(p)].filter(Boolean));
        const list = el("ul");
        // Current prices first; then the wholesaler we are on without a price, then the links; old prices last.
        for (const o of fresh.slice(0, 6)) list.append(priceRow(o));
        if (hereRow) list.append(hereRow);
        for (const l of otherLinks) list.append(linkRow(l));
        for (const o of old.slice(0, 4)) list.append(priceRow(o));
        box.append(el("div", { class: "label" },
          best ? "Nettopris hos grossistene dine (eks. mva)" : `Ingen priser nyere enn ${LMPrices.MAX_AGE_DAYS} dager`), list);
        if (hereOffer && Number(hereOffer.net_per_measure_unit) > bestPrice) {
          const pct = Math.round((1 - bestPrice / Number(hereOffer.net_per_measure_unit)) * 100);
          box.append(el("p", { class: "muted" }, `Du sparer ${pct} % ved å kjøpe den hos ${best.wholesaler_name.trim()}.`));
        }
        if (shopPrice) {
          box.append(el("div", { class: "row" }, el("span", {}, "Pris her (inkl. mva)"), el("span", { class: "num" }, kr(shopPrice))));
          const diff = best ? shopPrice / 1.25 - bestPrice : 0;
          if (diff > 0) {
            box.append(el("p", { class: "muted" }, `Du kjøper den ${LMPrices.formatPerUnit(diff, LMPrices.unitName(best.measure_unit))} billigere eks. mva hos ${best.wholesaler_name.trim()}.`));
          }
        }
        const shops = (res.shops ?? []).filter((s) => s.shop !== host);
        if (shops.length) {
          const prices = shops.map((s) => Number(s.price)).concat(shopPrice ? [shopPrice] : []);
          box.append(el("div", { class: "row" },
            el("span", {}, `Butikkpris, median av ${prices.length} butikker`),
            el("span", { class: "num" }, kr(median(prices)))));
        }
      }
      // Ad space, being tried out: testers only, always marked and below the prices.
      if (res?.tester) {
        box.append(el("div", { class: "ad" },
          el("span", { class: "ad-label" }, "Annonse"),
          el("strong", {}, "Din annonse her"),
          el("span", { class: "muted" }, "Her kan en produsent vise et produkt. Bare testbrukere ser denne.")));
      }
      if (res?.signedIn) box.append(el("a", { href: SITE, target: "_blank", rel: "noopener" }, "Åpne LettMateriell"));
    }
    mount(box, docked ? "dock" : "float");
  }

  const STYLE = `
    .box { width: 290px; font: 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif; color: #1f2933;
      background: #fff; border: 1px solid #c9d1d9; box-shadow: 0 8px 24px rgba(0,0,0,.18); padding: 10px 12px; }
    .head { display: flex; justify-content: space-between; align-items: center; gap: 8px; margin-bottom: 6px; }
    .collapsed .head { margin-bottom: 0; }
    .headline { color: #2f8f5b; }
    .headline.good { color: #1e7a46; }
    .buttons { display: flex; gap: 2px; flex-shrink: 0; }
    .icon { border: 0; background: none; font-size: 16px; line-height: 1; cursor: pointer; color: #6b7785; padding: 0 3px; }
    .collapsed { width: auto; max-width: 290px; }
    .box.bare { width: auto; padding: 0; border: 0; background: none !important; box-shadow: none; }
    .bare .icon { width: 40px; height: 40px; border-radius: 50%; background: #2f8f5b; color: #fff; font-size: 15px;
      line-height: 40px; padding: 0; box-shadow: 0 4px 14px rgba(0,0,0,.25); }
    .bare .icon:hover { background: #257549; }
    li a { display: inline; margin: 0; color: inherit; text-decoration: underline; text-underline-offset: 2px; }
    li.here { background: rgba(37, 99, 235, .08); }
    .tag { margin-left: 6px; font-size: 10px; text-transform: uppercase; letter-spacing: .04em; color: #2563eb;
      border: 1px solid currentColor; padding: 0 4px; }
    .ad { display: flex; flex-direction: column; gap: 2px; margin-top: 8px; padding: 6px 8px; border: 1px dashed #c9d1d9; }
    .ad-label { align-self: flex-start; font-size: 10px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
      color: #6b7785; border: 1px solid #c9d1d9; padding: 0 5px; }
    .name { font-weight: 600; margin-bottom: 2px; }
    .numbers { font-size: 12px; color: #6b7785; margin-bottom: 6px; font-variant-numeric: tabular-nums; }
    .label { font-size: 11px; color: #6b7785; text-transform: uppercase; letter-spacing: .03em; }
    ul { list-style: none; margin: 4px 0 8px; padding: 0; }
    li, .row { display: flex; justify-content: space-between; gap: 8px; padding: 2px 0; }
    li.best { color: #1e7a46; font-weight: 700; }
    li.old { color: #7b8590; }
    li.old .old-tag { color: inherit; }
    .when { display: block; font-size: 11px; color: #6b7785; }
    .num { font-variant-numeric: tabular-nums; white-space: nowrap; }
    .row { border-top: 1px solid #e3e8ee; padding-top: 5px; }
    .muted { color: #6b7785; margin: 4px 0; }
    a { display: inline-block; margin-top: 6px; color: #2563eb; }
    .box.docked { width: 100%; max-height: calc(100vh - 32px); box-sizing: border-box; overflow-y: auto; padding: 0 12px 10px;
      font-size: 12.5px; color: #d8dde1; background: #1f252b; border: 1px solid #3a434c; border-right: 0;
      border-radius: 8px 0 0 8px; box-shadow: 0 4px 16px rgba(0, 0, 0, .25); }
    .docked .head { position: sticky; top: 0; z-index: 1; margin: 0 -12px 8px; padding: 10px 12px 8px;
      background: inherit; border-bottom: 1px solid #e3e8ee; align-items: flex-start; }
    .docked ul { margin: 2px 0 6px; }
    .docked a { margin-top: 2px; }
    .brand { font-size: 10px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; color: #6fd39b; }
    .docked .headline { display: block; margin-top: 1px; font-size: 14px; color: #eef1f3; }
    .docked .headline.good { color: #1e7a46; }
    .docked .icon { font-size: 20px; padding: 4px 10px; margin: -4px -10px 0 0; border-radius: 4px; }
    .loading { display: flex; align-items: center; gap: 8px; color: #6b7785; margin: 10px 0 6px; }
    .spinner { width: 14px; height: 14px; border: 2px solid #d5dbe1; border-top-color: #2f8f5b; border-radius: 50%;
      animation: lm-spin .8s linear infinite; }
    .skel { height: 14px; margin: 10px 0; border-radius: 3px; background: linear-gradient(90deg, #e9edf0 25%, #f4f6f8 50%, #e9edf0 75%);
      background-size: 200% 100%; animation: lm-shimmer 1.2s ease-in-out infinite; }
    .skel.short { width: 60%; }
    @keyframes lm-spin { to { transform: rotate(360deg); } }
    @keyframes lm-shimmer { from { background-position: 200% 0; } to { background-position: -200% 0; } }
    .tab { writing-mode: vertical-rl; border: 0; cursor: pointer; padding: 14px 7px; border-radius: 6px 0 0 6px;
      background: #2f8f5b; color: #fff; font: 600 12px/1 system-ui, -apple-system, "Segoe UI", sans-serif; letter-spacing: .04em; }
    .tab:hover { background: #257549; }
    .action { margin-top: 6px; border: 1px solid #2f8f5b; background: #fff; color: #2f8f5b; padding: 5px 10px;
      cursor: pointer; font: inherit; border-radius: 4px; }
    /* The wholesalers' panel is always dark (Magnus' choice 2026-11-17). */
    .docked .head { border-bottom-color: #363d44; }
    .docked .headline.good, .docked li.best { color: #6fd39b; }
    .docked .row { border-top-color: #363d44; }
    .docked a, .docked .tag { color: #7aa7ff; }
    .docked li.here { background: rgba(122, 167, 255, .1); }
    .docked .ad, .docked .ad-label { border-color: #3a434c; }
    .docked li.old, .docked .muted, .docked .numbers, .docked .label, .docked .when, .docked .icon, .docked .loading { color: #8a949e; }
    .docked .icon:hover { background: rgba(255, 255, 255, .08); }
    .docked .skel { background: #2a3138; animation: none; }
    .docked .spinner { border-color: #3a434c; border-top-color: #6fd39b; }
    .docked .action { background: transparent; color: #6fd39b; border-color: #6fd39b; }
    @media (prefers-reduced-motion: reduce) { .spinner, .skel { animation: none; } }
    @media (prefers-color-scheme: dark) {
      /* Shops' bubble only: the wholesalers' panel is always dark (below). */
      .box:not(.docked) { background: #1f252b; color: #d8dde1; border-color: #3a434c; }
      .box:not(.docked) li.best, .box:not(.docked) .headline.good { color: #6fd39b; }
      .box:not(.docked) .row { border-top-color: #363d44; }
      .box:not(.docked) a, .box:not(.docked) .tag { color: #7aa7ff; }
      .box:not(.docked) li.here { background: rgba(122, 167, 255, .1); }
      .box:not(.docked) .ad, .box:not(.docked) .ad-label { border-color: #3a434c; }
      .box:not(.docked) li.old { color: #8a949e; }
    }`;

  // When to look at the page: once it has loaded, when it changes (shops load prices
  // and switch product without reloading) and when the address changes. Each page
  // is read at most MAX_TRIES times, and not at all once its product is found.
  const MAX_TRIES = 8;
  let pageUrl = location.href;
  let tries = 0;
  let timer = null;
  let running = false;

  function schedule(delay) {
    clearTimeout(timer);
    timer = setTimeout(run, delay);
  }

  async function run() {
    if (location.href !== pageUrl) {
      pageUrl = location.href;
      tries = 0;
      pageDone = false;
      lastCapture = "";
    }
    if (running) return schedule(700); // look again when this check is done
    if (pageDone || tries >= MAX_TRIES) return;
    tries++;
    running = true;
    try {
      await check();
    } finally {
      running = false;
    }
  }

  // Changes to the page, settled for a moment (the bubble lives outside <body>, so it does not count).
  new MutationObserver(() => {
    if (!pageDone || location.href !== pageUrl) schedule(700);
    scheduleCards();
  }).observe(document.body, { childList: true, subtree: true, characterData: true });
  scheduleCards();
  // A new address without a page load (single-page shops): a cheap check, no reading.
  setInterval(() => {
    if (location.href !== pageUrl) schedule(0);
  }, 1000);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") schedule(0);
  });
  // The choice of wholesalers is read before the first look, and a change shows at once.
  chrome.storage.local.get("disabledSites").then(({ disabledSites = [] }) => {
    off = new Set(disabledSites);
    schedule(0);
  }, () => schedule(0));
  chrome.storage.onChanged.addListener((changes) => {
    if (!changes.disabledSites) return;
    off = new Set(changes.disabledSites.newValue ?? []);
    lastKey = "";
    pageDone = false;
    tries = 0;
    schedule(0);
  });
})();
