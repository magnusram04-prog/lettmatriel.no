const $ = (id) => document.getElementById(id);
const send = (message) => chrome.runtime.sendMessage(message);

$("site").href = globalThis.LM_CONFIG.siteUrl;

let signingUp = false;
// «Opprett firma»: sign-up where company name and organisation number are required.
let creatingCompany = false;

/** Signed in without a company yet: the first user from the company gives its name and organisation number. */
function askCompany(text) {
  $("start").hidden = true;
  $("signed-in").hidden = true;
  $("login").hidden = true;
  $("company-form").hidden = false;
  if (text) $("company-intro").textContent = text;
  $("company-name").focus();
}

/** Signed out: the start screen with «Logg inn» and «Registrer deg» comes first. */
function show(email, company) {
  $("company-form").hidden = true;
  $("signed-in").hidden = !email;
  $("login").hidden = true;
  $("start").hidden = !!email;
  if (email) {
    $("email").textContent = email;
    $("company").hidden = !company;
    if (company) {
      $("company").textContent = company.joined
        ? `Du er med i ${company.name} sammen med kollegene dine.`
        : `Firma: ${company.name}`;
    }
  }
}

/** The form behind «Logg inn» or «Registrer deg». */
function openForm(signup, createCompany = false) {
  $("start").hidden = true;
  $("login").hidden = false;
  setMode(signup, createCompany);
  $("login-email").focus();
}

function setMode(signup, createCompany = false) {
  signingUp = signup;
  creatingCompany = signup && createCompany;
  $("login-intro").hidden = signup;
  $("signup-intro").hidden = !signup || creatingCompany;
  $("create-intro").hidden = !creatingCompany;
  $("company-hint").hidden = creatingCompany;
  $("login-company").required = creatingCompany;
  $("login-orgnr").required = creatingCompany;
  $("signup-fields").hidden = !signup;
  $("login-password2").required = signup;
  $("login-password").autocomplete = signup ? "new-password" : "current-password";
  $("submit").textContent = creatingCompany ? "Opprett firma" : signup ? "Registrer deg" : "Logg inn";
  $("switch").textContent = signup ? "Har du konto? Logg inn" : "Ny bruker? Registrer deg";
  $("error").hidden = true;
  $("info").hidden = true;
}

/** A Norwegian organisation number: 9 digits with a modulus 11 check digit (also checked by the database). */
function validOrgNr(n) {
  if (!/^\d{9}$/.test(n)) return false;
  const sum = [3, 2, 7, 6, 5, 4, 3, 2].reduce((s, w, i) => s + w * Number(n[i]), 0);
  const check = (11 - (sum % 11)) % 11;
  return check !== 10 && check === Number(n[8]);
}

function message(id, text) {
  $(id).textContent = text;
  $(id).hidden = false;
}

$("switch").addEventListener("click", () => setMode(!signingUp));
$("start-login").addEventListener("click", () => openForm(false));
$("start-signup").addEventListener("click", () => openForm(true));
$("start-company").addEventListener("click", () => openForm(true, true));
$("back").addEventListener("click", () => show(null));

$("login").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("error").hidden = true;
  $("info").hidden = true;
  const email = $("login-email").value;
  const password = $("login-password").value;
  if (signingUp && password !== $("login-password2").value) {
    message("error", "Passordene er ikke like.");
    return;
  }
  const orgNr = $("login-orgnr").value.replace(/\s/g, "");
  if (signingUp && orgNr && !validOrgNr(orgNr)) {
    message("error", "Organisasjonsnummeret finnes ikke. Sjekk at du har skrevet det riktig.");
    return;
  }
  $("submit").disabled = true;
  $("submit").textContent = signingUp ? "Registrerer…" : "Logger inn…";
  const res = signingUp
    ? await send({ type: "signUp", email, password, company: $("login-company").value, orgNr: $("login-orgnr").value })
    : await send({ type: "signIn", email, password });
  $("submit").disabled = false;
  $("login-password").value = "";
  $("login-password2").value = "";
  if (res?.error) {
    setMode(signingUp);
    message("error", res.error);
  } else if (signingUp) {
    setMode(false);
    message("info", "Sjekk e-posten din og trykk på lenken for å bekrefte kontoen. Logg så inn her.");
  } else if (res.needsCompany) {
    setMode(false);
    askCompany(res.needsCompany);
  } else {
    setMode(false);
    const status = await send({ type: "status" });
    $("ad").hidden = status?.tester !== true;
    show(res.email, status?.company);
  }
});

$("company-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("company-error").hidden = true;
  $("company-submit").disabled = true;
  const res = await send({ type: "setupCompany", name: $("company-name").value, orgNr: $("company-orgnr").value });
  $("company-submit").disabled = false;
  if (res?.error) message("company-error", res.error);
  else if (res?.needsCompany) message("company-error", res.needsCompany);
  else {
    const status = await send({ type: "status" });
    $("ad").hidden = status?.tester !== true;
    show(status?.email, status?.company);
  }
});

$("company-logout").addEventListener("click", async () => {
  await send({ type: "signOut" });
  show(null);
});

$("logout").addEventListener("click", async () => {
  await send({ type: "signOut" });
  $("ad").hidden = true;
  show(null);
});

$("capture").addEventListener("change", (e) => send({ type: "setCapture", on: e.target.checked }));

const sites = globalThis.LMReaders.sites();
$("capture-sites").textContent = sites.length
  ? `Virker foreløpig hos: ${sites.join(", ")}.`
  : "Grossistene legges til etter hvert som sidene deres er sjekket.";

send({ type: "status" }).then((res) => {
  $("capture").checked = res?.capture !== false;
  // The ad space is being tried out: testers only for now.
  $("ad").hidden = res?.tester !== true;
  // Signed in, and the database says the company is still to be made: ask for it.
  if (res?.email && res.needsCompany) askCompany(res.needsCompany);
  else show(res?.email ?? null, res?.company);
});

// «Deals»: today's campaigns, loaded when the section is opened.
const SITE_NAMES = {
  "ahlsell.no": "Ahlsell",
  "dahl.no": "Brødrene Dahl",
  "onninen.no": "Onninen",
  "solarnorge.no": "Solar",
  "heidenreich.no": "Heidenreich",
  "berggardamundsen.no": "Berggård Amundsen",
  "elektroimportoren.no": "Elektroimportøren",
};
let dealsLoaded = false;

function dealItem(d) {
  const li = document.createElement("li");
  if (d.mine) li.className = "mine";
  const a = document.createElement("a");
  a.href = d.url;
  a.target = "_blank";
  a.rel = "noopener";
  a.textContent = d.name;
  const meta = document.createElement("span");
  meta.className = "meta";
  meta.textContent = [SITE_NAMES[d.site] ?? d.site, d.el_nr && `EL ${d.el_nr}`, d.label || d.campaign]
    .filter(Boolean).join(" · ");
  li.append(a, meta);
  return li;
}

function dealGroup(title, deals) {
  const frag = document.createDocumentFragment();
  if (!deals.length) return frag;
  const h = document.createElement("h2");
  h.textContent = `${title} (${deals.length})`;
  const ul = document.createElement("ul");
  for (const d of deals) ul.append(dealItem(d));
  frag.append(h, ul);
  return frag;
}

$("deals").addEventListener("toggle", async () => {
  if (!$("deals").open || dealsLoaded) return;
  dealsLoaded = true;
  const res = await send({ type: "deals" });
  const list = $("deals-list");
  list.textContent = "";
  const off = await disabledSites();
  const deals = (Array.isArray(res?.deals) ? res.deals : []).filter((d) => !off.has(d.site));
  if (res?.error || !deals.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = res?.error ? "Fikk ikke hentet kampanjene akkurat nå." : "Ingen kampanjer funnet ennå. De hentes hver natt.";
    list.append(p);
    dealsLoaded = !res?.error;
    return;
  }
  list.append(dealGroup("For varene deres", deals.filter((d) => d.mine)), dealGroup("Alle kampanjer", deals.filter((d) => !d.mine)));
});

// «Grossister du bruker»: switched-off wholesalers are kept in storage as «disabledSites».
async function disabledSites() {
  const { disabledSites: list = [] } = await chrome.storage.local.get("disabledSites");
  return new Set(list);
}

async function showSites() {
  const off = await disabledSites();
  const list = $("sites-list");
  list.textContent = "";
  for (const [site, name] of Object.entries(SITE_NAMES)) {
    const label = document.createElement("label");
    label.className = "check";
    const box = document.createElement("input");
    box.type = "checkbox";
    box.checked = !off.has(site);
    box.addEventListener("change", async () => {
      const now = await disabledSites();
      if (box.checked) now.delete(site);
      else now.add(site);
      await chrome.storage.local.set({ disabledSites: [...now] });
      // The deals list is drawn again with the new choice next time it is opened.
      dealsLoaded = false;
      if ($("deals").open) $("deals").dispatchEvent(new Event("toggle"));
    });
    label.append(box, ` ${name}`);
    list.append(label);
  }
}
showSites();
