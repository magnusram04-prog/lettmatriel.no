// How to read the company's own net prices on each wholesaler's site, while
// the user is signed in there. Every wholesaler shows prices differently, so a
// site is added here only after its pages have been checked with a real
// account: a wrong reader would save wrong prices (with VAT, or list prices).
//
// A reader gets the page's document and returns the prices shown on it:
//   [{ el_nr, nrf_nr, gtin, name, price }]  – price excl. VAT, per piece/meter
// or [] when the page shows none (or the user is not signed in).
//
// No wholesaler is checked yet, so READERS is empty and no prices are saved from any of them.
// The functions below that are not in READERS are kept for later, and are not in use.
(function (root) {
  /**
   * For product pages that describe the product in JSON-LD or microdata,
   * with the signed-in customer's price excl. VAT. Use only where that has
   * been checked to hold.
   */
  function productPage(doc) {
    const X = root.LMExtract;
    const ld = X.fromJsonLd([...doc.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? ""));
    const text = X.fromText(textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000));
    const p = X.merge(text, ld);
    if (!p.price || !(p.elNr || p.nrfNr || p.gtin)) return [];
    return [{ el_nr: p.elNr, nrf_nr: p.nrfNr, gtin: p.gtin, name: p.name, price: p.price }];
  }

  /** «275,12 eks. mva.» → 275.12; «2 367,20» and «649,-» too. */
  const amount = (s) => root.LMExtract.parsePrice(String(s ?? "").replace(/\s+/g, ""));

  /**
   * The price excl. VAT per piece/meter in a price box: the number marked «eks. mva»
   * (else the one marked «inkl. mva», less 25 % VAT), divided by «Pris per 25 Stykk».
   */
  function priceFromBox(text) {
    const t = text.replace(/\s+/g, " ");
    // «2 367,20»: a space only between groups of three, and not starting inside another number.
    const number = "(?<![\\d,])(\\d{1,3}(?: \\d{3})*(?:,\\d{1,2}|,-))";
    const ex = t.match(new RegExp(number + " ?eks\\.? ?mva", "i"));
    const inc = t.match(new RegExp(number + " ?inkl\\.? ?mva", "i"));
    const total = ex ? amount(ex[1]) : inc ? amount(inc[1]) / 1.25 : null;
    if (!total) return null;
    const per = t.match(/pris per (\d+)/i);
    const qty = per ? Number(per[1]) : 1;
    return qty > 0 ? Math.round((total / qty) * 10000) / 10000 : null;
  }

  /** An element's text with a space between its parts («343,90» «275,12 eks. mva.» are separate elements). */
  function textOf(el) {
    if (!el) return "";
    if (!el.ownerDocument?.createTreeWalker) return el.textContent ?? "";
    const parts = [];
    const walker = el.ownerDocument.createTreeWalker(el, 4 /* NodeFilter.SHOW_TEXT */);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) parts.push(n.nodeValue);
    return parts.join(" ");
  }

  /**
   * IKKE I BRUK. Elektroimportøren: the product's own price box at the top of the page
   * (.toparticle), not the boxes of variants and accessories further down. It
   * shows the price the visitor gets: the shop price, or the company's price
   * when signed in to a business account. Checked 2026-10-27 on
   * /wago-koblingsklemme-221-415-5-leder-transparent/1221905/Product.html.
   * Ikke i bruk før innloggingsmerket er sjekket med ekte konto: uten innlogging
   * vises butikkprisen, og den må ikke lagres som nettopris.
   */
  function elektroimportoren(doc) {
    const box = doc.querySelector(".toparticle .product-price");
    if (!box) return [];
    const price = priceFromBox(textOf(box));
    if (!price) return [];
    // The numbers are in a folded section of the page, so the whole text is read.
    const X = root.LMExtract;
    const ld = X.fromJsonLd([...doc.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? ""));
    const m = X.merge(X.fromText(textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000)), ld);
    if (!(m.elNr || m.nrfNr || m.gtin)) return [];
    const name = m.name ?? doc.querySelector("h1")?.textContent?.trim() ?? null;
    return [{ el_nr: m.elNr, nrf_nr: m.nrfNr, gtin: m.gtin, name, price }];
  }

  // A price: «81,88», «1 234,50» (also with a narrow space or a dot between thousands), «649,-».
  const PRICE = /(?<![\d,])\d{1,3}(?:[   .]\d{3})*(?:,\d{2}|,-)(?!\d)/g;
  const GOOD = /din pris|nettopris|netto|kundepris|avtalepris|din netto/i;
  const PRICE_WORD = /pris|kr\b|nok|,-|mva/i;
  const BAD = /veil|listepris|bruttopris|ordinær|før\b|tidligere|spar\b|frakt|gebyr|miljø/i;
  const ASIDE = /related|recommend|carousel|slider|tilbeh|accessor|similar|alternativ|kjøpt sammen/i;

  /** The text right around an element: itself and up to two levels up, kept short. */
  function contextOf(el) {
    let ctx = el;
    for (let i = 0; i < 2 && ctx.parentElement && (ctx.textContent ?? "").length < 120; i++) ctx = ctx.parentElement;
    return textOf(ctx).replace(/\s+/g, " ").slice(0, 240);
  }

  function depth(el) {
    let d = 0;
    for (let e = el; e; e = e.parentElement) d++;
    return d;
  }

  /** How many levels apart two elements are (through their nearest common ancestor). */
  function distance(a, b) {
    const up = new Set();
    for (let e = a; e; e = e.parentElement) up.add(e);
    let common = b;
    while (common && !up.has(common)) common = common.parentElement;
    return common ? depth(a) + depth(b) - 2 * depth(common) : 99;
  }

  /**
   * IKKE I BRUK før siden er sjekket med ekte konto: en gjetning skal aldri lagres
   * som firmaets nettopris. Gjetter bare; lagrer ikke noe.
   *
   * The signed-in customer's price on a wholesaler's product page, when the page
   * has no fixed place for it: every number with a comma is scored by the words
   * around it («din pris», «netto», «kr», «eks. mva» up; «veil.», «før»,
   * «inkl. mva» down), by how close it is to the product name and the «Legg i
   * handlekurv» button, and by size; related products and menus are skipped.
   * Returns the price excl. VAT per piece/meter, or null when nothing is likely
   * enough (e.g. not signed in, so no price is shown).
   */
  function guessPrice(doc) {
    // Not signed in: the page says so, and any number on it is something else.
    if (/logg inn for (å se )?(dine |din )?(priser?|lagerstatus og pris)/i.test(textOf(doc.body))) return null;
    const anchors = [
      doc.querySelector("h1"),
      [...doc.querySelectorAll("button, a, input[type=submit]")].find((b) =>
        /legg i (handle)?kurv|kjøp|bestill/i.test(b.textContent || b.value || "")
      ),
    ].filter(Boolean);
    const view = doc.defaultView;
    let best = null;
    const walker = doc.createTreeWalker(doc.body, 4 /* text */);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const text = n.nodeValue ?? "";
      if (!/\d,(\d{2}|-)/.test(text)) continue;
      const el = n.parentElement;
      if (!el || el.closest("script, style, nav, header, footer, aside, select, option")) continue;
      // Struck-through prices are old prices.
      if (el.closest("s, del, strike")) continue;
      const hidden = view?.getComputedStyle(el);
      if (hidden && (hidden.display === "none" || hidden.visibility === "hidden")) continue;
      let asideHit = false;
      for (let e = el, i = 0; e && i < 8; e = e.parentElement, i++) {
        if (ASIDE.test(`${e.id} ${e.className}`)) asideHit = true;
      }
      for (const m of text.matchAll(PRICE)) {
        // «0,75 kg», «1,5 mm»: a measure, not a price.
        if (/^\s*(kg|g|mm|cm|m|m2|m²|w|kw|v|a|ah|mah|l|%|°)\b/i.test(text.slice(m.index + m[0].length))) continue;
        // A price's label stands before it («Pris 18 757,96», «Listepris 20 845,00»), back to the
        // previous price; after it only the unit and VAT («kr / stk eks. mva»). So «Listepris» after
        // the customer's price does not count against it.
        const around = contextOf(el);
        const at = around.indexOf(m[0]);
        let before = at < 0 ? "" : around.slice(Math.max(0, at - 50), at);
        const lastPrice = [...before.matchAll(PRICE)].pop();
        if (lastPrice) before = before.slice(lastPrice.index + lastPrice[0].length);
        const after = at < 0 ? around : around.slice(at + m[0].length, at + m[0].length + 20);
        const ctx = `${before} ${m[0]} ${after}`;
        let score = 0;
        if (GOOD.test(before)) score += 4;
        if (PRICE_WORD.test(ctx)) score += 2;
        if (/eks\.?\s*mva|ekskl|eksklusiv/i.test(ctx)) score += 2;
        if (/inkl\.?\s*mva/i.test(ctx) && !/eks/i.test(ctx)) score -= 1;
        if (BAD.test(before)) score -= 4;
        if (asideHit) score -= 5;
        const near = Math.min(99, ...anchors.map((a) => distance(a, el)));
        score += near <= 4 ? 3 : near <= 7 ? 1 : 0;
        if (parseFloat(hidden?.fontSize ?? "0") >= 18) score += 1;
        if (!PRICE_WORD.test(ctx) && !GOOD.test(ctx)) continue; // a number with no price words is not a price
        if (!best || score > best.score) best = { score, value: m[0], ctx };
      }
    }
    if (!best || best.score < 4) return null;
    let total = amount(best.value.replace(/[   .](?=\d{3})/g, ""));
    if (!total) return null;
    if (/inkl\.?\s*mva/i.test(best.ctx) && !/eks/i.test(best.ctx)) total /= 1.25;
    const per = best.ctx.match(/(?:per|pr\.?|\/)\s*(\d+)\s*(stk|stykk|m\b|meter|pk)/i);
    const qty = per && Number(per[1]) > 1 ? Number(per[1]) : 1;
    return Math.round((total / qty) * 10000) / 10000;
  }

  /** IKKE I BRUK før siden er sjekket med ekte konto (gjettet pris). For wholesalers without a checked price box: the product numbers and the best-guess price. */
  function bestGuess(doc) {
    const price = guessPrice(doc);
    if (!price) return [];
    const X = root.LMExtract;
    const ld = X.fromJsonLd([...doc.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? ""));
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const m = X.merge(X.fromSite(loc.hostname, loc.pathname, text), X.fromText(text), ld);
    if (!(m.elNr || m.nrfNr || m.gtin)) return [];
    const name = m.name ?? doc.querySelector("h1")?.textContent?.trim() ?? null;
    return [{ el_nr: m.elNr, nrf_nr: m.nrfNr, gtin: m.gtin, name, price }];
  }

  // Site (without www.) → reader. Empty until a wholesaler's reader is checked with a real account
  // (signed in, and the price shown is the company's net price). Add a site here only then.
  const READERS = {};

  /** The reader for a host name, or null. */
  function readerFor(host) {
    const site = Object.keys(READERS).find((s) => host === s || host.endsWith("." + s));
    return site ? READERS[site] : null;
  }

  root.LMReaders = { textOf, productPage, priceFromBox, elektroimportoren, guessPrice, bestGuess, readerFor, sites: () => Object.keys(READERS) };
})(globalThis);
