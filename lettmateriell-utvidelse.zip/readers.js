// How to read the company's own net prices on each wholesaler's site, while
// the user is signed in there. Every wholesaler shows prices differently, so a
// site is added here only after its pages have been checked with a real
// account: a wrong reader would save wrong prices (with VAT, or list prices).
//
// A reader gets the page's document and returns the prices shown on it:
//   [{ el_nr, nrf_nr, gtin, name, price }]  – price excl. VAT, per piece/meter
// or [] when the page shows none (or the user is not signed in).
//
// Checked with a real account: Onninen and Brødrene Dahl (2026-11-13), Elektroimportøren
// (2026-11-14). The other sites have no reader, and no prices are saved there. guessPrice and
// bestGuess are kept for later, and are not in use.
(function (root) {
  /**
   * For product pages that describe the product in JSON-LD or microdata,
   * with the signed-in customer's price excl. VAT. Use only where that has
   * been checked to hold.
   */
  function productPage(doc) {
    const X = root.LMExtract;
    const ld = X.fromJsonLd([...doc.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? ""));
    const text = X.fromText(textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000));
    const p = X.merge(text, ld);
    if (!p.price || !(p.elNr || p.nrfNr || p.gtin)) return [];
    return [{ el_nr: p.elNr, nrf_nr: p.nrfNr, gtin: p.gtin, name: p.name, price: p.price }];
  }

  /** «275,12 eks. mva.» → 275.12; «2 367,20» and «649,-» too. */
  const amount = (s) => root.LMExtract.parsePrice(String(s ?? "").replace(/\s+/g, ""));

  /**
   * The price excl. VAT per piece/meter in a price box: the number marked «eks. mva»
   * (else the one marked «inkl. mva», less 25 % VAT), divided by «Pris per 25 Stykk».
   */
  function priceFromBox(text) {
    const t = text.replace(/\s+/g, " ");
    // «2 367,20»: a space only between groups of three, and not starting inside another number.
    const number = "(?<![\\d,])(\\d{1,3}(?: \\d{3})*(?:,\\d{1,2}|,-))";
    const ex = t.match(new RegExp(number + " ?eks\\.? ?mva", "i"));
    const inc = t.match(new RegExp(number + " ?inkl\\.? ?mva", "i"));
    const total = ex ? amount(ex[1]) : inc ? amount(inc[1]) / 1.25 : null;
    if (!total) return null;
    const per = t.match(/pris per (\d+)/i);
    const qty = per ? Number(per[1]) : 1;
    return qty > 0 ? Math.round((total / qty) * 10000) / 10000 : null;
  }

  /** An element's text with a space between its parts («343,90» «275,12 eks. mva.» are separate elements). */
  function textOf(el) {
    if (!el) return "";
    if (!el.ownerDocument?.createTreeWalker) return el.textContent ?? "";
    const parts = [];
    const walker = el.ownerDocument.createTreeWalker(el, 4 /* NodeFilter.SHOW_TEXT */);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) parts.push(n.nodeValue);
    return parts.join(" ");
  }

  /**
   * Elektroimportøren, from the parts of a product page (checked 2026-11-14 with a real
   * account, /wago-koblingsklemme-221-415-5-leder-transparent/1221905/Product.html). Signed in:
   * the «Min side» menu (.mypage-menu) lists «Mine tidligere kjøp», not «Registrer deg». The
   * product's own price box (.toparticle .product-price) shows the price excl. VAT, the price
   * incl. VAT and the quantity: «11,- 13,76 inkl. mva. Pris per 1 Stykk», or with the label
   * «275,12 eks. mva. Pris per 25 Stykk». An offer also shows the old price («Ordinærpris»):
   * the price excl. VAT is the number that is the price incl. VAT less 25 %.
   */
  function elektroimportorenFromParts({ signedIn, boxText, elNr, gtin, name }) {
    if (!signedIn || !elNr) return [];
    const t = String(boxText ?? "").replace(/\s+/g, " ");
    const number = "(?<![\\d,])(\\d{1,3}(?: \\d{3})*(?:,\\d{1,2}|,-))";
    const per = /pris per (\d+) ([a-zæøå]+)/i.exec(t);
    const unit = per ? unitOf(per[2]) : null;
    const qty = per ? Number(per[1]) : 0;
    if (!unit || !(qty > 0)) return [];
    let ex = null;
    const labelled = t.match(new RegExp(number + " ?eks\\.? ?mva", "i"));
    if (labelled) ex = money(labelled[1]);
    else {
      const inc = t.match(new RegExp(number + " ?inkl\\.? ?mva", "i"));
      const incl = inc ? money(inc[1]) : null;
      if (!incl) return [];
      const before = t.slice(0, inc.index);
      // The number shown with it that is the price incl. VAT less 25 % (to the øre, both rounded).
      for (const m of before.matchAll(new RegExp(number, "g"))) {
        const n = money(m[1]);
        if (n && Math.abs(n * 1.25 - incl) <= 0.02 + incl * 0.001) ex = n;
      }
    }
    if (!ex) return [];
    const price = Math.round((ex / qty) * 10000) / 10000;
    return [{ el_nr: elNr, nrf_nr: null, gtin: gtin ?? null, name: name ?? null, price, unit }];
  }

  function elektroimportoren(doc) {
    const X = root.LMExtract;
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const menu = [...doc.querySelectorAll(".mypage-menu")].map((e) => textOf(e)).join(" ");
    // The numbers are in a folded section of the page, so the whole text is read.
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    return elektroimportorenFromParts({
      signedIn: /tidligere kjøp|min side/i.test(menu) && !/registrer deg/i.test(menu),
      boxText: textOf(doc.querySelector(".toparticle .product-price")),
      elNr: X.fromSite(loc.hostname, loc.pathname, text).elNr ?? null,
      gtin: X.fromText(text).gtin,
      name: doc.querySelector("h1")?.textContent?.trim() || null,
    });
  }

  // A price: «81,88», «1 234,50» (also with a narrow space or a dot between thousands), «649,-».
  const PRICE = /(?<![\d,])\d{1,3}(?:[   .]\d{3})*(?:,\d{2}|,-)(?!\d)/g;
  const GOOD = /din pris|nettopris|netto|kundepris|avtalepris|din netto/i;
  const PRICE_WORD = /pris|kr\b|nok|,-|mva/i;
  const BAD = /veil|listepris|bruttopris|ordinær|før\b|tidligere|spar\b|frakt|gebyr|miljø/i;
  const ASIDE = /related|recommend|carousel|slider|tilbeh|accessor|similar|alternativ|kjøpt sammen/i;

  /** The text right around an element: itself and up to two levels up, kept short. */
  function contextOf(el) {
    let ctx = el;
    for (let i = 0; i < 2 && ctx.parentElement && (ctx.textContent ?? "").length < 120; i++) ctx = ctx.parentElement;
    return textOf(ctx).replace(/\s+/g, " ").slice(0, 240);
  }

  function depth(el) {
    let d = 0;
    for (let e = el; e; e = e.parentElement) d++;
    return d;
  }

  /** How many levels apart two elements are (through their nearest common ancestor). */
  function distance(a, b) {
    const up = new Set();
    for (let e = a; e; e = e.parentElement) up.add(e);
    let common = b;
    while (common && !up.has(common)) common = common.parentElement;
    return common ? depth(a) + depth(b) - 2 * depth(common) : 99;
  }

  /**
   * IKKE I BRUK før siden er sjekket med ekte konto: en gjetning skal aldri lagres
   * som firmaets nettopris. Gjetter bare; lagrer ikke noe.
   *
   * The signed-in customer's price on a wholesaler's product page, when the page
   * has no fixed place for it: every number with a comma is scored by the words
   * around it («din pris», «netto», «kr», «eks. mva» up; «veil.», «før»,
   * «inkl. mva» down), by how close it is to the product name and the «Legg i
   * handlekurv» button, and by size; related products and menus are skipped.
   * Returns the price excl. VAT per piece/meter, or null when nothing is likely
   * enough (e.g. not signed in, so no price is shown).
   */
  function guessPrice(doc) {
    // Not signed in: the page says so, and any number on it is something else.
    if (/logg inn for (å se )?(dine |din )?(priser?|lagerstatus og pris)/i.test(textOf(doc.body))) return null;
    const anchors = [
      doc.querySelector("h1"),
      [...doc.querySelectorAll("button, a, input[type=submit]")].find((b) =>
        /legg i (handle)?kurv|kjøp|bestill/i.test(b.textContent || b.value || "")
      ),
    ].filter(Boolean);
    const view = doc.defaultView;
    let best = null;
    const walker = doc.createTreeWalker(doc.body, 4 /* text */);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const text = n.nodeValue ?? "";
      if (!/\d,(\d{2}|-)/.test(text)) continue;
      const el = n.parentElement;
      if (!el || el.closest("script, style, nav, header, footer, aside, select, option")) continue;
      // Struck-through prices are old prices.
      if (el.closest("s, del, strike")) continue;
      const hidden = view?.getComputedStyle(el);
      if (hidden && (hidden.display === "none" || hidden.visibility === "hidden")) continue;
      let asideHit = false;
      for (let e = el, i = 0; e && i < 8; e = e.parentElement, i++) {
        if (ASIDE.test(`${e.id} ${e.className}`)) asideHit = true;
      }
      for (const m of text.matchAll(PRICE)) {
        // «0,75 kg», «1,5 mm»: a measure, not a price.
        if (/^\s*(kg|g|mm|cm|m|m2|m²|w|kw|v|a|ah|mah|l|%|°)\b/i.test(text.slice(m.index + m[0].length))) continue;
        // A price's label stands before it («Pris 18 757,96», «Listepris 20 845,00»), back to the
        // previous price; after it only the unit and VAT («kr / stk eks. mva»). So «Listepris» after
        // the customer's price does not count against it.
        const around = contextOf(el);
        const at = around.indexOf(m[0]);
        let before = at < 0 ? "" : around.slice(Math.max(0, at - 50), at);
        const lastPrice = [...before.matchAll(PRICE)].pop();
        if (lastPrice) before = before.slice(lastPrice.index + lastPrice[0].length);
        const after = at < 0 ? around : around.slice(at + m[0].length, at + m[0].length + 20);
        const ctx = `${before} ${m[0]} ${after}`;
        let score = 0;
        if (GOOD.test(before)) score += 4;
        if (PRICE_WORD.test(ctx)) score += 2;
        if (/eks\.?\s*mva|ekskl|eksklusiv/i.test(ctx)) score += 2;
        if (/inkl\.?\s*mva/i.test(ctx) && !/eks/i.test(ctx)) score -= 1;
        if (BAD.test(before)) score -= 4;
        if (asideHit) score -= 5;
        const near = Math.min(99, ...anchors.map((a) => distance(a, el)));
        score += near <= 4 ? 3 : near <= 7 ? 1 : 0;
        if (parseFloat(hidden?.fontSize ?? "0") >= 18) score += 1;
        if (!PRICE_WORD.test(ctx) && !GOOD.test(ctx)) continue; // a number with no price words is not a price
        if (!best || score > best.score) best = { score, value: m[0], ctx };
      }
    }
    if (!best || best.score < 4) return null;
    let total = amount(best.value.replace(/[   .](?=\d{3})/g, ""));
    if (!total) return null;
    if (/inkl\.?\s*mva/i.test(best.ctx) && !/eks/i.test(best.ctx)) total /= 1.25;
    const per = best.ctx.match(/(?:per|pr\.?|\/)\s*(\d+)\s*(stk|stykk|m\b|meter|pk)/i);
    const qty = per && Number(per[1]) > 1 ? Number(per[1]) : 1;
    return Math.round((total / qty) * 10000) / 10000;
  }

  /** IKKE I BRUK før siden er sjekket med ekte konto (gjettet pris). For wholesalers without a checked price box: the product numbers and the best-guess price. */
  function bestGuess(doc) {
    const price = guessPrice(doc);
    if (!price) return [];
    const X = root.LMExtract;
    const ld = X.fromJsonLd([...doc.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? ""));
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const m = X.merge(X.fromSite(loc.hostname, loc.pathname, text), X.fromText(text), ld);
    if (!(m.elNr || m.nrfNr || m.gtin)) return [];
    const name = m.name ?? doc.querySelector("h1")?.textContent?.trim() ?? null;
    return [{ el_nr: m.elNr, nrf_nr: m.nrfNr, gtin: m.gtin, name, price }];
  }

  /** «stk», «stykk» → "stk"; «m», «meter» → "m"; any other unit (pk, tub, rull …) → null: not saved. */
  function unitOf(text) {
    const u = String(text ?? "").trim().toLowerCase();
    if (/^(stk|stykk)\.?$/.test(u)) return "stk";
    if (/^(m|meter)\.?$/.test(u)) return "m";
    return null;
  }

  const money = (s) => {
    const n = root.LMExtract.parsePrice(String(s ?? "").replace(/[\s  ]/g, ""));
    return n && n > 0 ? n : null;
  };

  /**
   * Onninen, from the parts of a product page (checked 2026-11-13 with a real account,
   * /pmflex-k-r-r-16-pn-3g2-5-r100/p/DTI970). Signed in: the header shows the customer
   * selector «Konto». The customer's own price is in the product's price box
   * ([data-test="product-description__customer_price"]): «18,35 kr / m», excl. VAT; the
   * «Listepris» under it is not. The EL number is the page data's «electCode».
   */
  function onninenFromParts({ signedIn, priceText, unitText, elNr, gtin, name }) {
    if (!signedIn || !elNr) return [];
    const price = money(priceText);
    const unit = unitOf(unitText);
    if (!price || !unit) return [];
    return [{ el_nr: elNr, nrf_nr: null, gtin: gtin ?? null, name: name ?? null, price, unit }];
  }

  function onninen(doc) {
    const box = doc.querySelector('.product-pricing [data-test="product-description__customer_price"] .customer-price');
    const X = root.LMExtract;
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const scripts = [...doc.querySelectorAll("script:not([src])")].map((s) => s.textContent ?? "").join("\n");
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    return onninenFromParts({
      signedIn: !!doc.querySelector(".desktop-customer-selector__label"),
      priceText: box?.querySelector(".number")?.textContent,
      unitText: box?.querySelector(".unit")?.textContent,
      elNr: X.fromSite(loc.hostname, loc.pathname, text, scripts).elNr ?? null,
      gtin: X.fromText(text).gtin,
      name: doc.querySelector("h1")?.textContent?.trim() || null,
    });
  }

  /**
   * Brødrene Dahl, from the parts of a product page (checked 2026-11-13 with a real account,
   * …/t-ror-nr-130.-sort-adusert-m3c_bd_66ab432c05943a3ea8b46613?v=M3C_BD_101819294).
   * Signed in: the top bar shows «KONTO: <number> <company>» (not inside <header>). The customer's price is in the
   * row of the product's own «Kjøp (n)» button: «53,63 per stk», excl. VAT. Accessories further
   * down have their own rows. When «Pris og rabatter» is open, «Bruttopris» less «Din rabatt»
   * must give the same price, else nothing is saved. The product is the one whose «VARENR» is
   * the page address's v=…; its «NRF» is the number after it.
   */
  function dahlFromParts({ headerText, rowText, sectionText, varenr, pageText, name }) {
    if (!/konto:\s*\d+/i.test(headerText ?? "")) return [];
    const row = /(\d{1,3}(?:[\s  .]\d{3})*,\d{2})\s*per\s+([a-zæøå]+)/i.exec(rowText ?? "");
    if (!row) return [];
    const price = money(row[1]);
    const unit = unitOf(row[2]);
    if (!price || !unit) return [];
    const gross = /bruttopris\s*:?\s*(?:kr\s*)?(\d{1,3}(?:[\s  .]\d{3})*,\d{2})/i.exec(sectionText ?? "");
    const discount = /din rabatt\s*:?\s*(\d{1,2}(?:,\d+)?)\s*%/i.exec(sectionText ?? "");
    if (gross && discount) {
      // The discount is shown in whole per cent (65 % for 65.4 %): half a per cent of the gross either way.
      const g = money(gross[1]);
      const expected = g * (1 - Number(discount[1].replace(",", ".")) / 100);
      if (!(Math.abs(expected - price) <= g * 0.005 + 0.02)) return [];
    }
    if (!varenr) return [];
    const m = new RegExp(`varenr\\s*${varenr}\\D{0,20}?nrf\\s*(\\d{7})(?!\\d)`, "i").exec(pageText ?? "");
    if (!m) return [];
    return [{ el_nr: null, nrf_nr: m[1], gtin: null, name: name ?? null, price, unit }];
  }

  function dahl(doc) {
    const buy = [...doc.querySelectorAll("button")].find((b) => /^\s*kjøp\s*\(\d+\)\s*$/i.test(b.textContent ?? ""));
    let row = buy;
    for (let i = 0; i < 6 && row && !/\d,\d{2}\s*per\s/i.test(textOf(row)); i++) row = row.parentElement;
    const section = [...doc.querySelectorAll("*")].find((e) =>
      e.children.length < 40 && /bruttopris/i.test(e.textContent ?? "") && /din rabatt/i.test(e.textContent ?? "") &&
      (e.textContent ?? "").length < 600
    );
    const href = doc.location?.href ?? "";
    const v = /[?&]v=M3C_BD_(\d+)/i.exec(href);
    return dahlFromParts({
      headerText: textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000),
      rowText: row ? textOf(row).replace(/\s+/g, " ") : "",
      sectionText: section ? textOf(section).replace(/\s+/g, " ") : "",
      varenr: v ? v[1] : null,
      pageText: textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000),
      name: doc.querySelector("h1")?.textContent?.trim() || null,
    });
  }

  // Site (without www.) → reader. A site is added only after its pages have been checked with a
  // real account (signed in, and the price read is the company's net price excl. VAT).
  const READERS = { "onninen.no": onninen, "dahl.no": dahl, "elektroimportoren.no": elektroimportoren };

  /** The reader for a host name, or null. */
  function readerFor(host) {
    const site = Object.keys(READERS).find((s) => host === s || host.endsWith("." + s));
    return site ? READERS[site] : null;
  }

  root.LMReaders = {
    textOf,
    productPage,
    priceFromBox,
    elektroimportoren,
    elektroimportorenFromParts,
    guessPrice,
    bestGuess,
    unitOf,
    onninenFromParts,
    dahlFromParts,
    onninen,
    dahl,
    readerFor,
    sites: () => Object.keys(READERS),
  };
})(globalThis);
