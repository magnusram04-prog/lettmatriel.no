// How to read the company's own net prices on each wholesaler's site, while
// the user is signed in there. Every wholesaler shows prices differently, so a
// site is added here only after its pages have been checked with a real
// account: a wrong reader would save wrong prices (with VAT, or list prices).
//
// A reader gets the page's document and returns the prices shown on it:
//   [{ el_nr, nrf_nr, gtin, name, price }]  – price excl. VAT, per piece/meter
// or [] when the page shows none (or the user is not signed in).
//
// Checked with a real account: Onninen and Brødrene Dahl (2026-11-13), Elektroimportøren
// and Ahlsell (2026-11-14), Solar (2026-11-17), Malmbergs, Etman and Eldirekte (2026-11-26). The other sites have no reader, and no prices are saved there. guessPrice and
// bestGuess are kept for later, and are not in use.
(function (root) {
  /**
   * For product pages that describe the product in JSON-LD or microdata,
   * with the signed-in customer's price excl. VAT. Use only where that has
   * been checked to hold.
   */
  function productPage(doc) {
    const X = root.LMExtract;
    const ld = X.fromJsonLd([...doc.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? ""));
    const text = X.fromText(textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000));
    const p = X.merge(text, ld);
    if (!p.price || !(p.elNr || p.nrfNr || p.gtin)) return [];
    return [{ el_nr: p.elNr, nrf_nr: p.nrfNr, gtin: p.gtin, name: p.name, price: p.price }];
  }

  /** «275,12 eks. mva.» → 275.12; «2 367,20» and «649,-» too. */
  const amount = (s) => root.LMExtract.parsePrice(String(s ?? "").replace(/\s+/g, ""));

  /**
   * The price excl. VAT per piece/meter in a price box: the number marked «eks. mva»
   * (else the one marked «inkl. mva», less 25 % VAT), divided by «Pris per 25 Stykk».
   */
  function priceFromBox(text) {
    const t = text.replace(/\s+/g, " ");
    // «2 367,20»: a space only between groups of three, and not starting inside another number.
    const number = "(?<![\\d,])(\\d{1,3}(?: \\d{3})*(?:,\\d{1,2}|,-))";
    const ex = t.match(new RegExp(number + " ?eks\\.? ?mva", "i"));
    const inc = t.match(new RegExp(number + " ?inkl\\.? ?mva", "i"));
    const total = ex ? amount(ex[1]) : inc ? amount(inc[1]) / 1.25 : null;
    if (!total) return null;
    const per = t.match(/pris per (\d+)/i);
    const qty = per ? Number(per[1]) : 1;
    return qty > 0 ? Math.round((total / qty) * 10000) / 10000 : null;
  }

  /** An element's text with a space between its parts («343,90» «275,12 eks. mva.» are separate elements). */
  function textOf(el) {
    if (!el) return "";
    if (!el.ownerDocument?.createTreeWalker) return el.textContent ?? "";
    const parts = [];
    const walker = el.ownerDocument.createTreeWalker(el, 4 /* NodeFilter.SHOW_TEXT */);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) parts.push(n.nodeValue);
    return parts.join(" ");
  }

  /**
   * Elektroimportøren, from the parts of a product page (checked 2026-11-14 with a real
   * account, /wago-koblingsklemme-221-415-5-leder-transparent/1221905/Product.html). Signed in:
   * the «Min side» menu (.mypage-menu) lists «Mine tidligere kjøp», not «Registrer deg». The
   * product's own price box (.toparticle .product-price) shows the price excl. VAT, the price
   * incl. VAT and the quantity: «11,- 13,76 inkl. mva. Pris per 1 Stykk», or with the label
   * «275,12 eks. mva. Pris per 25 Stykk». An offer also shows the old price («Ordinærpris»):
   * the price excl. VAT is the number that is the price incl. VAT less 25 %.
   */
  function elektroimportorenFromParts({ signedIn, boxText, elNr, gtin, name }) {
    if (!signedIn || !elNr) return [];
    const t = String(boxText ?? "").replace(/\s+/g, " ");
    const number = "(?<![\\d,])(\\d{1,3}(?: \\d{3})*(?:,\\d{1,2}|,-))";
    const per = /pris per (\d+) ([a-zæøå]+)/i.exec(t);
    const unit = per ? unitOf(per[2]) : null;
    const qty = per ? Number(per[1]) : 0;
    if (!unit || !(qty > 0)) return [];
    let ex = null;
    const labelled = t.match(new RegExp(number + " ?eks\\.? ?mva", "i"));
    if (labelled) ex = money(labelled[1]);
    else {
      const inc = t.match(new RegExp(number + " ?inkl\\.? ?mva", "i"));
      const incl = inc ? money(inc[1]) : null;
      if (!incl) return [];
      const before = t.slice(0, inc.index);
      // The number shown with it that is the price incl. VAT less 25 % (to the øre, both rounded).
      for (const m of before.matchAll(new RegExp(number, "g"))) {
        const n = money(m[1]);
        if (n && Math.abs(n * 1.25 - incl) <= 0.02 + incl * 0.001) ex = n;
      }
    }
    if (!ex) return [];
    const price = Math.round((ex / qty) * 10000) / 10000;
    return [{ el_nr: elNr, nrf_nr: null, gtin: gtin ?? null, name: name ?? null, price, unit }];
  }

  function elektroimportoren(doc) {
    const X = root.LMExtract;
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const menu = [...doc.querySelectorAll(".mypage-menu")].map((e) => textOf(e)).join(" ");
    // The numbers are in a folded section of the page, so the whole text is read.
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    return elektroimportorenFromParts({
      signedIn: /tidligere kjøp|min side/i.test(menu) && !/registrer deg/i.test(menu),
      boxText: textOf(doc.querySelector(".toparticle .product-price")),
      elNr: X.fromSite(loc.hostname, loc.pathname, text).elNr ?? null,
      gtin: X.fromText(text).gtin,
      name: doc.querySelector("h1")?.textContent?.trim() || null,
    });
  }

  /**
   * Malmbergs, from the parts of a product page (checked 2026-11-26 with a real account,
   * malmbergs.com/Products/1018561). Signed in: the top bar has «Logg ut». The price box
   * (.product-details .price) shows the customer's price first (.price-new, red), the
   * ordinary price struck out (.price-old) and «eks. MVA». The same site serves Sweden in
   * «kr» too, so only a box that says «eks. MVA» is read. «Enhet» is STYKK or METER.
   */
  function malmbergsFromParts({ signedIn, priceText, vatText, unitText, elNr, name }) {
    if (!signedIn || !elNr || !/eks\.?\s*mva/i.test(String(vatText ?? ""))) return [];
    const price = money(String(priceText ?? "").replace(/kr/i, ""));
    const unit = unitOf(unitText);
    if (!price || !unit) return [];
    return [{ el_nr: elNr, nrf_nr: null, gtin: null, name: name ?? null, price, unit }];
  }

  function malmbergs(doc) {
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const box = doc.querySelector(".product-details .price");
    const unitRow = [...doc.querySelectorAll("#productoverviewtable tr")]
      .find((r) => /^\s*enhet\s*$/i.test(r.cells?.[0]?.textContent ?? ""));
    return malmbergsFromParts({
      signedIn: [...doc.querySelectorAll("a")].some((a) => /^\s*logg ut\s*$/i.test(a.textContent ?? "")),
      priceText: (box?.querySelector(".price-new .product-price") ?? box?.querySelector(".product-price"))?.textContent,
      vatText: box?.querySelector(".vat")?.textContent,
      unitText: unitRow?.cells?.[1]?.textContent,
      elNr: root.LMExtract.elFromUrl(loc.hostname, loc.pathname),
      name: doc.querySelector(".product-details h2")?.textContent?.trim() || null,
    });
  }

  /**
   * Etman, from the parts of a product page (checked 2026-11-26 with a real account,
   * etman.no/product.vm?id=24104, Mosaic 1243876). Signed in: a «Logg ut» link. The price box
   * (.product-detail-price) shows the customer's price (.price-new, 228,69), the ordinary price
   * struck out (.price-old) and «ekskl. mva.». «Prisenhet» is STK or MTR.
   */
  function etmanFromParts({ signedIn, priceText, vatText, unitText, elNr, name }) {
    if (!signedIn || !elNr || !/eks(kl)?\.?\s*mva/i.test(String(vatText ?? ""))) return [];
    const price = money(priceText);
    const unit = unitOf(unitText);
    if (!price || !unit) return [];
    return [{ el_nr: elNr, nrf_nr: null, gtin: null, name: name ?? null, price, unit }];
  }

  function etman(doc) {
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const box = doc.querySelector(".product-detail-price");
    const row = (label) => [...doc.querySelectorAll("table.table-sm tr")]
      .map((r) => (r.textContent ?? "").replace(/\s+/g, " ").trim())
      .find((t) => t.toLowerCase().startsWith(label));
    return etmanFromParts({
      signedIn: [...doc.querySelectorAll("a")].some((a) => /^\s*logg ut\s*$/i.test(a.textContent ?? "")),
      priceText: box?.querySelector(".price-new")?.textContent,
      vatText: box?.querySelector(".mva")?.textContent,
      unitText: row("prisenhet")?.replace(/^prisenhet:?\s*/i, ""),
      elNr: root.LMExtract.fromSite(loc.hostname, loc.pathname, row("produktnummer") ?? "").elNr ?? null,
      name: doc.querySelector("h1")?.textContent?.trim() || null,
    });
  }

  /**
   * Eldirekte, from the parts of a product page (checked 2026-11-26 with a real account,
   * …/sg-stikkontakt-dobbel-innfelt-m-j-hvit/cat-p/c1000339/p1500017321). An online shop: everyone,
   * signed in or not, sees the same price incl. VAT («Inkl. Mva 49,-»); excl. VAT is that less 25 %.
   * «Varenummer: 1501362» and «EAN: …» under the picture. No unit: cable says «(metervare)» in its
   * name and is per metre; a pack is skipped; anything else is per piece.
   */
  function eldirekteFromParts({ priceText, vatText, elNr, gtin, name }) {
    if (!elNr || !/inkl\.?\s*mva/i.test(String(vatText ?? ""))) return [];
    const n = String(name ?? "");
    // A pack: «(10 stk)», «10 stk», «10pk», «pakke»: the price is not per piece.
    if (/\b(pakke?|pakning|pk|pack)\b|\d-?pa?kk?\b|\b([2-9]|\d{2,})\s*stk\b/i.test(n)) return [];
    const incl = money(priceText);
    if (!incl) return [];
    const unit = /metervare/i.test(n) ? "m" : "stk";
    return [{ el_nr: elNr, nrf_nr: null, gtin: gtin ?? null, name: name ?? null, price: Math.round((incl / 1.25) * 10000) / 10000, unit }];
  }

  function eldirekte(doc) {
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const sku = [...doc.querySelectorAll(".b-product-sku")].map((e) => textOf(e)).join(" ").replace(/\s+/g, " ");
    const box = doc.querySelector('[id$="price_block"]');
    const gtin = (sku.match(/\bEAN\s*:?\s*(\d{8,14})\b/i) ?? [])[1];
    return eldirekteFromParts({
      priceText: box?.querySelector(".b-product-price__main")?.textContent?.replace(/inkl\.?\s*mva/i, ""),
      vatText: box?.textContent,
      elNr: root.LMExtract.fromSite(loc.hostname, loc.pathname, sku).elNr ?? null,
      gtin: gtin && root.LMExtract.validGtin(gtin) ? gtin : null,
      name: doc.querySelector("h1")?.textContent?.replace(/\s+/g, " ").trim() || null,
    });
  }

  // A price: «81,88», «1 234,50» (also with a narrow space or a dot between thousands), «649,-».
  const PRICE =/(?<![\d,])\d{1,3}(?:[   .]\d{3})*(?:,\d{2}|,-)(?!\d)/g;
  const GOOD = /din pris|nettopris|netto|kundepris|avtalepris|din netto/i;
  const PRICE_WORD = /pris|kr\b|nok|,-|mva/i;
  const BAD = /veil|listepris|bruttopris|ordinær|før\b|tidligere|spar\b|frakt|gebyr|miljø/i;
  const ASIDE = /related|recommend|carousel|slider|tilbeh|accessor|similar|alternativ|kjøpt sammen/i;

  /** The text right around an element: itself and up to two levels up, kept short. */
  function contextOf(el) {
    let ctx = el;
    for (let i = 0; i < 2 && ctx.parentElement && (ctx.textContent ?? "").length < 120; i++) ctx = ctx.parentElement;
    return textOf(ctx).replace(/\s+/g, " ").slice(0, 240);
  }

  function depth(el) {
    let d = 0;
    for (let e = el; e; e = e.parentElement) d++;
    return d;
  }

  /** How many levels apart two elements are (through their nearest common ancestor). */
  function distance(a, b) {
    const up = new Set();
    for (let e = a; e; e = e.parentElement) up.add(e);
    let common = b;
    while (common && !up.has(common)) common = common.parentElement;
    return common ? depth(a) + depth(b) - 2 * depth(common) : 99;
  }

  /**
   * IKKE I BRUK før siden er sjekket med ekte konto: en gjetning skal aldri lagres
   * som firmaets nettopris. Gjetter bare; lagrer ikke noe.
   *
   * The signed-in customer's price on a wholesaler's product page, when the page
   * has no fixed place for it: every number with a comma is scored by the words
   * around it («din pris», «netto», «kr», «eks. mva» up; «veil.», «før»,
   * «inkl. mva» down), by how close it is to the product name and the «Legg i
   * handlekurv» button, and by size; related products and menus are skipped.
   * Returns the price excl. VAT per piece/meter, or null when nothing is likely
   * enough (e.g. not signed in, so no price is shown).
   */
  function guessPrice(doc) {
    // Not signed in: the page says so, and any number on it is something else.
    if (/logg inn for (å se )?(dine |din )?(priser?|lagerstatus og pris)/i.test(textOf(doc.body))) return null;
    const anchors = [
      doc.querySelector("h1"),
      [...doc.querySelectorAll("button, a, input[type=submit]")].find((b) =>
        /legg i (handle)?kurv|kjøp|bestill/i.test(b.textContent || b.value || "")
      ),
    ].filter(Boolean);
    const view = doc.defaultView;
    let best = null;
    const walker = doc.createTreeWalker(doc.body, 4 /* text */);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const text = n.nodeValue ?? "";
      if (!/\d,(\d{2}|-)/.test(text)) continue;
      const el = n.parentElement;
      if (!el || el.closest("script, style, nav, header, footer, aside, select, option")) continue;
      // Struck-through prices are old prices.
      if (el.closest("s, del, strike")) continue;
      const hidden = view?.getComputedStyle(el);
      if (hidden && (hidden.display === "none" || hidden.visibility === "hidden")) continue;
      let asideHit = false;
      for (let e = el, i = 0; e && i < 8; e = e.parentElement, i++) {
        if (ASIDE.test(`${e.id} ${e.className}`)) asideHit = true;
      }
      for (const m of text.matchAll(PRICE)) {
        // «0,75 kg», «1,5 mm»: a measure, not a price.
        if (/^\s*(kg|g|mm|cm|m|m2|m²|w|kw|v|a|ah|mah|l|%|°)\b/i.test(text.slice(m.index + m[0].length))) continue;
        // A price's label stands before it («Pris 18 757,96», «Listepris 20 845,00»), back to the
        // previous price; after it only the unit and VAT («kr / stk eks. mva»). So «Listepris» after
        // the customer's price does not count against it.
        const around = contextOf(el);
        const at = around.indexOf(m[0]);
        let before = at < 0 ? "" : around.slice(Math.max(0, at - 50), at);
        const lastPrice = [...before.matchAll(PRICE)].pop();
        if (lastPrice) before = before.slice(lastPrice.index + lastPrice[0].length);
        const after = at < 0 ? around : around.slice(at + m[0].length, at + m[0].length + 20);
        const ctx = `${before} ${m[0]} ${after}`;
        let score = 0;
        if (GOOD.test(before)) score += 4;
        if (PRICE_WORD.test(ctx)) score += 2;
        if (/eks\.?\s*mva|ekskl|eksklusiv/i.test(ctx)) score += 2;
        if (/inkl\.?\s*mva/i.test(ctx) && !/eks/i.test(ctx)) score -= 1;
        if (BAD.test(before)) score -= 4;
        if (asideHit) score -= 5;
        const near = Math.min(99, ...anchors.map((a) => distance(a, el)));
        score += near <= 4 ? 3 : near <= 7 ? 1 : 0;
        if (parseFloat(hidden?.fontSize ?? "0") >= 18) score += 1;
        if (!PRICE_WORD.test(ctx) && !GOOD.test(ctx)) continue; // a number with no price words is not a price
        if (!best || score > best.score) best = { score, value: m[0], ctx };
      }
    }
    if (!best || best.score < 4) return null;
    let total = amount(best.value.replace(/[   .](?=\d{3})/g, ""));
    if (!total) return null;
    if (/inkl\.?\s*mva/i.test(best.ctx) && !/eks/i.test(best.ctx)) total /= 1.25;
    const per = best.ctx.match(/(?:per|pr\.?|\/)\s*(\d+)\s*(stk|stykk|m\b|meter|pk)/i);
    const qty = per && Number(per[1]) > 1 ? Number(per[1]) : 1;
    return Math.round((total / qty) * 10000) / 10000;
  }

  /** IKKE I BRUK før siden er sjekket med ekte konto (gjettet pris). For wholesalers without a checked price box: the product numbers and the best-guess price. */
  function bestGuess(doc) {
    const price = guessPrice(doc);
    if (!price) return [];
    const X = root.LMExtract;
    const ld = X.fromJsonLd([...doc.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? ""));
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const m = X.merge(X.fromSite(loc.hostname, loc.pathname, text), X.fromText(text), ld);
    if (!(m.elNr || m.nrfNr || m.gtin)) return [];
    const name = m.name ?? doc.querySelector("h1")?.textContent?.trim() ?? null;
    return [{ el_nr: m.elNr, nrf_nr: m.nrfNr, gtin: m.gtin, name, price }];
  }

  /**
   * «stk», «stykk», «rull» → "stk"; «m», «meter» → "m"; any other unit (pk, tub …) → null: not saved.
   * A roll is one piece: Elektroimportøren's «Pris per 1 Rull» tape is «NOK/STK» at Ahlsell and
   * «kr stk» at Onninen (2026-11-25, 1800367). A pack is not: it can hold 100 pieces.
   */
  function unitOf(text) {
    const u = String(text ?? "").trim().toLowerCase();
    // A set too: Elektroimportøren's «Pris per 1 Sett» fuse-box label set is «NOK/STK» at Ahlsell (1725455).
    if (/^(stk|stykk|rull|sett)\.?$/.test(u)) return "stk";
    if (/^(m|meter|mtr)\.?$/.test(u)) return "m"; // «MTR»: Etman
    return null;
  }

  /**
   * Metres in one piece, from a product name: «FRONT TEK123 80PV 2,5M», «F 80 PV L=2,5», «A/2.5m»,
   * «lengde 4M». Some wholesalers sell such lengths per metre, others per piece (2026-11-25), so the
   * database can turn one into the other. Only 0.5–12 m: longer is a cable drum, not a length.
   */
  function pieceFromName(name) {
    const all = [...String(name ?? "").matchAll(/(?:^|[\s\/=xX])(\d{1,2}(?:[.,]\d{1,2})?)\s*m(?:eter)?(?![a-zæøå²\d])|\bL=(\d{1,2}(?:[.,]\d{1,2})?)(?![\d,.])/gi)];
    const m = all.pop();
    const n = m ? Number((m[1] ?? m[2]).replace(",", ".")) : 0;
    return n >= 0.5 && n <= 12 ? n : null;
  }

  /** Each item with «piece_m» from its name, when the reader did not find it already. */
  function withPieces(items) {
    return items.map((i) => {
      if (i.piece_m) return i;
      const p = pieceFromName(i.name);
      return p ? { ...i, piece_m: p } : i;
    });
  }

  const money = (s) => {
    const n = root.LMExtract.parsePrice(String(s ?? "").replace(/[\s  ]/g, ""));
    return n && n > 0 ? n : null;
  };

  /**
   * Onninen, from the parts of a product page (checked 2026-11-13 with a real account,
   * /pmflex-k-r-r-16-pn-3g2-5-r100/p/DTI970). Signed in: the header shows the customer
   * selector «Konto». The customer's own price is in the product's price box
   * ([data-test="product-description__customer_price"]): «18,35 kr / m», excl. VAT; the
   * «Listepris» under it is not. The EL number is the page data's «electCode».
   */
  function onninenFromParts({ signedIn, priceText, unitText, elNr, gtin, name }) {
    if (!signedIn || !elNr) return [];
    const price = money(priceText);
    const unit = unitOf(unitText);
    if (!price || !unit) return [];
    return [{ el_nr: elNr, nrf_nr: null, gtin: gtin ?? null, name: name ?? null, price, unit }];
  }

  /** Onninen's spec rows: the EL number when the row «SAP» is the product in the address (/p/<code>). */
  function onninenSpecEl(doc) {
    const code = (doc.location?.pathname ?? "").match(/\/p\/([^/]+)\/?$/)?.[1];
    const value = (t) => doc.querySelector(`[data-test="specification-row-${t}"] .specification-row__value`)?.textContent?.trim() ?? "";
    const el = value("elec");
    return code && value("sap").toLowerCase() === code.toLowerCase() && /^\d{7}$/.test(el) ? el : null;
  }

  function onninen(doc) {
    // «Avtalepris»: an agreed price has its own box, without the customer price's.
    const box = doc.querySelector('.product-pricing [data-test="product-description__customer_price"] .customer-price') ??
      doc.querySelector(".product-pricing .agreed-product__price");
    const X = root.LMExtract;
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const scripts = [...doc.querySelectorAll("script:not([src])")].map((s) => s.textContent ?? "").join("\n");
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    return onninenFromParts({
      signedIn: !!doc.querySelector(".desktop-customer-selector__label"),
      priceText: box?.querySelector(".number")?.textContent,
      unitText: box?.querySelector(".unit")?.textContent,
      elNr: X.fromSite(loc.hostname, loc.pathname, text, scripts).elNr ?? onninenSpecEl(doc),
      gtin: X.fromText(text).gtin,
      name: doc.querySelector("h1")?.textContent?.trim() || null,
    });
  }

  /**
   * Brødrene Dahl, from the parts of a product page (checked 2026-11-13 with a real account,
   * …/t-ror-nr-130.-sort-adusert-m3c_bd_66ab432c05943a3ea8b46613?v=M3C_BD_101819294).
   * Signed in: the top bar shows «KONTO: <number> <company>» (not inside <header>). The customer's price is in the
   * row of the product's own «Kjøp (n)» button: «53,63 per stk», excl. VAT. Accessories further
   * down have their own rows. When «Pris og rabatter» is open, «Bruttopris» less «Din rabatt»
   * must give the same price, else nothing is saved. The product is the one whose «VARENR» is
   * the page address's v=…; its «NRF» is the number after it.
   */
  function dahlFromParts({ headerText, rowText, sectionText, varenr, pageText, name }) {
    if (!/konto:\s*\d+/i.test(headerText ?? "")) return [];
    const row = /(\d{1,3}(?:[\s  .]\d{3})*,\d{2})\s*per\s+([a-zæøå]+)/i.exec(rowText ?? "");
    if (!row) return [];
    const price = money(row[1]);
    const unit = unitOf(row[2]);
    if (!price || !unit) return [];
    const gross = /bruttopris\s*:?\s*(?:kr\s*)?(\d{1,3}(?:[\s  .]\d{3})*,\d{2})/i.exec(sectionText ?? "");
    const discount = /din rabatt\s*:?\s*(\d{1,2}(?:,\d+)?)\s*%/i.exec(sectionText ?? "");
    if (gross && discount) {
      // The discount is shown in whole per cent (65 % for 65.4 %): half a per cent of the gross either way.
      const g = money(gross[1]);
      const expected = g * (1 - Number(discount[1].replace(",", ".")) / 100);
      if (!(Math.abs(expected - price) <= g * 0.005 + 0.02)) return [];
    }
    if (!varenr) return [];
    const m = new RegExp(`varenr\\s*${varenr}\\D{0,20}?nrf\\s*(\\d{7})(?!\\d)`, "i").exec(pageText ?? "");
    if (!m) return [];
    return [{ el_nr: null, nrf_nr: m[1], gtin: null, name: name ?? null, price, unit }];
  }

  function dahl(doc) {
    const buy = [...doc.querySelectorAll("button")].find((b) => /^\s*kjøp\s*\(\d+\)\s*$/i.test(b.textContent ?? ""));
    let row = buy;
    for (let i = 0; i < 6 && row && !/\d,\d{2}\s*per\s/i.test(textOf(row)); i++) row = row.parentElement;
    const section = [...doc.querySelectorAll("*")].find((e) =>
      e.children.length < 40 && /bruttopris/i.test(e.textContent ?? "") && /din rabatt/i.test(e.textContent ?? "") &&
      (e.textContent ?? "").length < 600
    );
    const href = doc.location?.href ?? "";
    // «?v=M3C_BD_<varenr>», or the canonical address «…-m3c_bd_<varenr>» that search engines link to.
    const v = /[?&]v=M3C_BD_(\d+)/i.exec(href) ?? /-m3c_bd_(\d+)\/?$/i.exec(doc.location?.pathname ?? "");
    return dahlFromParts({
      headerText: textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000),
      rowText: row ? textOf(row).replace(/\s+/g, " ") : "",
      sectionText: section ? textOf(section).replace(/\s+/g, " ") : "",
      varenr: v ? v[1] : null,
      pageText: textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000),
      name: doc.querySelector("h1")?.textContent?.trim() || null,
    });
  }

  /**
   * Ahlsell, from the parts of a product page (checked 2026-11-14 with a real account,
   * /products/elektro/…/4901203---varmevifte-2kw/ and …/ferdigtrukket-kabelledning-i-ror/1226265/).
   * Signed in: the top bar shows «Mine sider» and the user with the customer number in
   * brackets. The customer's price is the product's own heading price «727,90 NOK/STK» or
   * «18,14 NOK/M» (p.text-heading-h3), excl. VAT (the variants table says «Pris ekskl. mva.»).
   * Not signed in: «Logg inn for lagerstatus og pris», and no price. With «Skjul pris» ticked
   * there is no price either. The EL number is in the address.
   */
  function ahlsellFromParts({ signedIn, priceText, elNr, gtin, name, packText }) {
    if (!signedIn || !elNr) return [];
    const m = /^\s*(\d{1,3}(?:[\s  .]\d{3})*,\d{2})\s*NOK\s*\/\s*([a-zæøå]+)\s*$/i.exec(String(priceText ?? ""));
    if (!m) return [];
    const price = money(m[1]);
    const unit = unitOf(m[2]);
    if (!price || !unit) return [];
    // A length sold per metre («Forpakningsstørrelser: 2.5 M/20 M/1200 M», 2026-11-25 on 1277430):
    // the smallest pack is one length, so the price per length can be compared where others sell it per piece.
    const pack = unit === "m" ? /forpakningsstørrelser\s*:?\s*(\d+(?:[.,]\d+)?)\s*M\b/i.exec(String(packText ?? "")) : null;
    const pieceM = pack ? Number(pack[1].replace(",", ".")) : 0;
    return [{ el_nr: elNr, nrf_nr: null, gtin: gtin ?? null, name: name ?? null, price, unit, ...(pieceM > 0 ? { piece_m: pieceM } : {}) }];
  }

  function ahlsell(doc) {
    const X = root.LMExtract;
    const loc = doc.location ?? { hostname: "", pathname: "" };
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    const prices = [...doc.querySelectorAll("p.text-heading-h3")].filter((p) => /NOK\s*\//i.test(p.textContent ?? ""));
    return ahlsellFromParts({
      signedIn: /mine sider/i.test(text) && /\(\d{5,}\)/.test(text) && !/logg inn for lagerstatus og pris/i.test(text),
      // Only one heading price on a product page; more than one is not a single product's page.
      priceText: prices.length === 1 ? prices[0].textContent : null,
      elNr: X.elFromUrl(loc.hostname, loc.pathname),
      gtin: X.fromText(text).gtin,
      name: doc.querySelector("h1")?.textContent?.trim() || null,
      packText: text,
    });
  }

  /**
   * Solar, from the parts of a product page (checked 2026-11-17 with a real account,
   * …/kobberkabler/1200626467/ and …/screw-less-terminal/1000693072/). Signed in: the blue top bar
   * has the account menu (button.c-blue-bar__account-menu) and the account list shows the
   * customer number. The price box (solar-price-details) has rows of label and value, in one of two
   * forms: «Pris pr 1 stk | Listepris 23,56 NOK | Rabatt 65,47% | Nettopris 8,14 NOK», or with a
   * special discount «Pris pr 1 m | Nettopris 42,29 NOK | Spesialrabatt 49,35% | Utsalgspris 21,42 NOK».
   * The customer's price is the last NOK row (Nettopris or Utsalgspris), excl. VAT (no row says
   * otherwise; the list price is NELFO's, excl. VAT). The first NOK row less the discount must give
   * it, else nothing is saved. The EL number is the details card's «Elnummer: 1221905».
   */
  function solarFromParts({ signedIn, rows, elNr, gtin, name }) {
    if (!signedIn || !elNr || !Array.isArray(rows)) return [];
    const clean = rows.map(([l, v]) => [String(l ?? "").replace(/\s+/g, " ").trim(), String(v ?? "").replace(/\s+/g, " ").trim()]);
    const per = clean.find(([l]) => /^pris pr\.?$/i.test(l));
    const pm = per && /^(\d+)\s*([a-zæøå]+)\.?$/i.exec(per[1]);
    const qty = pm ? Number(pm[1]) : 0;
    const unit = pm ? unitOf(pm[2]) : null;
    if (!unit || !(qty > 0)) return [];
    const nok = clean.filter(([, v]) => /^\d{1,3}(?:[\s  .]\d{3})*,\d{2}\s*NOK$/i.test(v));
    if (!nok.length) return [];
    const [label, value] = nok[nok.length - 1];
    if (!/^(nettopris|utsalgspris)$/i.test(label)) return [];
    const total = money(value.replace(/NOK/i, ""));
    if (!total) return [];
    if (nok.length > 1) {
      const pct = clean.find(([, v]) => /^\d{1,2}(?:,\d+)?\s*%$/.test(v));
      if (!pct) return [];
      const first = money(nok[0][1].replace(/NOK/i, ""));
      const expected = first * (1 - Number(pct[1].replace("%", "").replace(",", ".").trim()) / 100);
      if (!(Math.abs(expected - total) <= 0.02 + first * 0.0005)) return [];
    }
    const price = Math.round((total / qty) * 10000) / 10000;
    return [{ el_nr: elNr, nrf_nr: null, gtin: gtin ?? null, name: name ?? null, price, unit }];
  }

  function solar(doc) {
    const X = root.LMExtract;
    const boxes = doc.querySelectorAll("solar-price-details");
    // One price box on a product page; more than one is not a single product's page.
    const rows = boxes.length === 1
      ? [...boxes[0].querySelectorAll(":scope > div > div")].map((r) => {
        const parts = [...r.children].map((c) => textOf(c));
        return [parts[0] ?? "", parts[parts.length - 1] ?? ""];
      })
      : null;
    const card = textOf(doc.querySelector("solar-details-card-container")).replace(/\s+/g, " ");
    const el = /\belnummer\s*:?\s*(\d{7})(?!\d)/i.exec(card);
    const accounts = textOf(doc.querySelector(".account-items"));
    return solarFromParts({
      signedIn: !!doc.querySelector("button.c-blue-bar__account-menu") && /\d{5,}/.test(accounts),
      rows,
      elNr: el ? el[1] : null,
      gtin: X.fromText(card).gtin,
      name: doc.querySelector("h1")?.textContent?.trim() || null,
    });
  }

  /**
   * Solar's product cards (checked 2026-11-17 on a saved product page): the «recommended»
   * carousel (solar-carousel-item), and the same cards in result lists, show each product's
   * «Elnr.: 1221905», «EAN: 4055143234658» and a link to its page
   * (https://www.solarnorge.no/no-webshop/<category>/<Solar's number>/).
   * Result lists can show «Elnr.» without an EAN: then gtin is null, and the database takes the EAN
   * it has for that EL. A card without an EL number, with an EAN that is not valid, or with a link
   * that is not a product page, is left out.
   * Signed in, each card also shows the company's price, «45,09 NOK 22,73%» (search results checked
   * from a screenshot 2026-11-18), with the unit in the quantity box («1 stk»). The price is kept
   * only when the box names the unit (stk or m); without it, only the link is used.
   */
  function solarCardsFromParts(cards, signedIn = false) {
    const X = root.LMExtract;
    const out = new Map();
    for (const c of cards ?? []) {
      const el = /^\s*(\d{7})\s*$/.exec(String(c?.elText ?? ""))?.[1];
      const eanText = String(c?.eanText ?? "").trim();
      const gtin = /^(\d{8,14})$/.exec(eanText)?.[1] ?? null;
      const url = String(c?.href ?? "");
      if (!el || (eanText && !(gtin && X.validGtin(gtin)))) continue;
      if (!/^https:\/\/(www\.)?solarnorge\.no\/(?:no-webshop\/(?:[^/?#]+\/)+\d{6,}\/?|commerce\/content\/\d{3,}\/no\/?)$/.test(url)) continue;
      if (out.has(el)) continue;
      const card = { el_nr: el, gtin, url, name: String(c?.name ?? "").replace(/\s+/g, " ").trim() || null };
      // The company's price, when signed in: «45,09 NOK» per the unit in the quantity box («1 stk»).
      const pm = /^(\d{1,3}(?:[\s  .]\d{3})*,\d{2})\s*NOK\b/i.exec(String(c?.priceText ?? "").replace(/\s+/g, " ").trim());
      const unit = unitOf(/^\s*\d+(?:[.,]\d+)?\s*([a-zæøå]+)\.?\s*$/i.exec(String(c?.qtyText ?? ""))?.[1]);
      const price = signedIn && pm && unit ? money(pm[1]) : null;
      if (price && price < 10_000_000) Object.assign(card, { price, unit });
      out.set(el, card);
    }
    return [...out.values()];
  }

  function solarCards(doc) {
    // Product pages, or (search results) Solar's short link that leads to the product page.
    const isLink = (a) => /\/(?:no-webshop\/(?:[^/?#]+\/)+\d{6,}|commerce\/content\/\d{3,}\/no)\/?$/.test(a.href ?? "");
    const label = (root, re) => [...root.querySelectorAll("span")].find((s) => re.test((s.textContent ?? "").trim()));
    // «Elnr.:» with the number in the next element, or «Elnr.: 1221905» in one.
    const ELNR = /^Elnr\.?:\s*(\d{7})?$/i;
    const cards = [];
    // The «Elnr.» labels, found once: counting them again in every card's parents took 100 ms for 400 cards.
    const elLabels = [...doc.querySelectorAll("span")].filter((s) => ELNR.test((s.textContent ?? "").trim()));
    const labelsIn = (root) => elLabels.filter((s) => root.contains(s)).length;
    for (const span of elLabels) {
      const own = ELNR.exec((span.textContent ?? "").trim());
      // The card: the nearest element around the label with a product link, and only this one product.
      let card = span.parentElement;
      while (card && ![...card.querySelectorAll("a[href]")].some(isLink)) card = card.parentElement;
      if (!card) continue;
      if (labelsIn(card) !== 1) continue;
      const link = [...card.querySelectorAll("a[href]")].filter(isLink);
      const hrefs = new Set(link.map((a) => a.href));
      if (hrefs.size !== 1) continue;
      const ean = label(card, /^EAN:?$/i);
      // On category pages the price and quantity sit beside the card, not in it: widen to the
      // largest parent (a few levels up) that still holds only this one «Elnr.».
      let box = card;
      for (let i = 0; i < 4 && box.parentElement; i++) {
        const up = box.parentElement;
        if (labelsIn(up) !== 1) break;
        box = up;
      }
      // The price line: search results have the number with «NOK» in a span after it (and the
      // discount after that); category pages (checked 2026-11-18, signed in) have one
      // div.price-value «50,13 NOK», the same as «Nettopris» on the product page.
      const nok = [...box.querySelectorAll("span")].find((s) => /^NOK$/i.test((s.textContent ?? "").trim()));
      const values = [...box.querySelectorAll(".price-value")].filter((e) => /NOK/i.test(e.textContent ?? ""));
      const priceText = nok ? textOf(nok.parentElement) : values.length === 1 ? textOf(values[0]) : "";
      const qty = box.querySelector("input[role=spinbutton]") ?? box.querySelector('input[placeholder^="Ant"]');
      cards.push({
        priceText,
        qtyText: qty ? String(qty.value || qty.getAttribute("aria-valuetext") || "") : "",
        // «Elnr.:» then the number: in the next element (carousel) or as text after it (search results).
        elText: own[1] ?? (textOf(span.nextElementSibling).trim() || (/Elnr\.?:\s*(\d{7})\b/i.exec(textOf(span.parentElement))?.[1] ?? "")),
        eanText: ean ? textOf(ean.nextElementSibling) : "",
        href: link[0].href,
        name: link.map((a) => (a.textContent ?? "").trim()).find(Boolean) ?? link[0].querySelector("img")?.alt ?? "",
      });
    }
    const accounts = textOf(doc.querySelector(".account-items"));
    return solarCardsFromParts(cards, !!doc.querySelector("button.c-blue-bar__account-menu") && /\d{5,}/.test(accounts));
  }

  // ---- Lists of products with prices (search results, category pages, variant tables) ----
  // Each list reader returns { el_nr, nrf_nr, gtin, name, url?, price, unit } per product, only
  // when signed in. They are read from what the page shows, like the product pages.

  /**
   * Brødrene Dahl's search results and category pages (checked 2026-11-18, /sok?q=koblingsboks,
   * signed in): each card has «Varenr 101808354», «NRF 9720744», the name, and the price
   * «5 127,22 per stk» (the same as on the product page), with a link …?v=M3C_BD_<varenr>.
   */
  function dahlListFromParts({ headerText, cards }) {
    if (!/konto:\s*\d+/i.test(headerText ?? "")) return [];
    const out = new Map();
    for (const c of cards ?? []) {
      const text = String(c?.text ?? "").replace(/\s+/g, " ");
      const href = String(c?.href ?? "");
      const v = /^https:\/\/(?:www\.)?dahl\.no\/[^?#]*\?(?:[^#]*&)?v=M3C_BD_(\d+)/i.exec(href)?.[1];
      if (!v) continue;
      const nrf = new RegExp(`varenr\\s*${v}\\D{0,20}?nrf\\s*(\\d{7})(?!\\d)`, "i").exec(text)?.[1];
      // The numbers (Varenr, NRF) stand right before the price: taken out first, so that
      // «NRF 1401918 235,94 per stk» is not read as 918 235,94.
      const priceText = text.replace(/\b(?:varenr|nrf)\s*\d+/gi, " ");
      const prices = [...priceText.matchAll(/(?<![\d,])(\d{1,3}(?:[\s  .]\d{3})*,\d{2})\s*per\s+([a-zæøå]+)/gi)];
      if (!nrf || prices.length !== 1) continue;
      const price = money(prices[0][1]);
      const unit = unitOf(prices[0][2]);
      if (!price || !unit || out.has(nrf)) continue;
      out.set(nrf, { el_nr: null, nrf_nr: nrf, gtin: null, name: String(c?.name ?? "").trim() || null, url: href, price, unit });
    }
    return [...out.values()];
  }

  function dahlList(doc) {
    const byHref = new Map();
    for (const a of doc.querySelectorAll('a[href*="v=M3C_BD_"]')) {
      if (byHref.has(a.href)) continue;
      // The card: the nearest element around the link with its «Varenr» and a price, and no other product.
      let card = a;
      while (card && !(/varenr\s*\d/i.test(card.textContent ?? "") && /\d,\d{2}\s*per\s/i.test(card.textContent ?? ""))) {
        card = card.parentElement;
      }
      if (!card) continue;
      // The whole card can be the link itself (search results, 2026-11-18).
      const links = [card, ...card.querySelectorAll('a[href*="v=M3C_BD_"]')].filter((x) => x.matches?.('a[href*="v=M3C_BD_"]'));
      if (new Set(links.map((x) => x.href)).size !== 1) continue;
      const text = textOf(card).replace(/\s+/g, " ");
      byHref.set(a.href, { text, href: a.href, name: text.split(/\bvarenr\b/i)[0].trim().slice(0, 300) });
    }
    return dahlListFromParts({ headerText: textOf(doc.body).replace(/\s+/g, " ").slice(0, 3000), cards: [...byHref.values()] });
  }

  /**
   * Elektroimportøren's search results and category pages (checked 2026-11-18, ?query=Ap9, signed
   * in): each card (.product-overview-info) has a link …/<EL>/Product.html and a price box like
   * the product page's, «39,92 49,90 inkl. mva. Pris per 1 Stykk» (with the EL number in it).
   */
  function elektroimportorenListFromParts({ signedIn, cards }) {
    if (!signedIn) return [];
    const out = new Map();
    for (const c of cards ?? []) {
      // Some cards (campaign blocks, checked 2026-11-18) link with «?Event=» after Product.html:
      // the product is the same, and the link is kept without it.
      const m = /^(https:\/\/(?:www\.)?elektroimportoren\.no\/[^?#]*\/(\d{7})\/Product\.html)(?:[?#].*)?$/i.exec(String(c?.href ?? ""));
      const href = m?.[1] ?? "";
      const el = m?.[2];
      if (!el || out.has(el)) continue;
      const boxText = String(c?.boxText ?? "").split(el).join(" ");
      const [item] = elektroimportorenFromParts({ signedIn, boxText, elNr: el, gtin: null, name: String(c?.name ?? "").trim() || null });
      if (item) out.set(el, { ...item, url: href });
    }
    return [...out.values()];
  }

  function elektroimportorenList(doc) {
    const menu = [...doc.querySelectorAll(".mypage-menu")].map((e) => textOf(e)).join(" ");
    const cards = [...doc.querySelectorAll(".product-overview-info")].map((card) => {
      const link = [...card.querySelectorAll("a[href]")].find((a) => /\/\d{7}\/Product\.html(?:[?#]|$)/i.test(a.href));
      return {
        href: link?.href ?? "",
        boxText: textOf(card.querySelector(".product-price")).replace(/\s+/g, " "),
        name: card.querySelector(".product-name")?.textContent ?? "",
      };
    });
    return elektroimportorenListFromParts({
      signedIn: /tidligere kjøp|min side/i.test(menu) && !/registrer deg/i.test(menu),
      cards,
    });
  }

  /**
   * Ahlsell's variant lists (checked 2026-11-18 on …/innstikklemme/1221903/ and the category
   * pages, signed in): «Vis varianter» shows each variant's article number (the EL number) and
   * «4,33 NOK/STK» («Pris ekskl. mva.»), the same as the variant's own product page. The rows have
   * no link of their own. Category lists without the variants open show no prices.
   */
  function ahlsellListFromParts({ signedIn, rows }) {
    if (!signedIn) return [];
    const out = new Map();
    for (const r of rows ?? []) {
      const el = /^\s*(\d{7})\s*$/.exec(String(r?.elText ?? ""))?.[1];
      const m = /^\s*(\d{1,3}(?:[\s  .]\d{3})*,\d{2})\s*NOK\s*\/\s*([a-zæøå]+)\s*$/i.exec(String(r?.priceText ?? ""));
      if (!el || !m || out.has(el)) continue;
      const price = money(m[1]);
      const unit = unitOf(m[2]);
      if (!price || !unit) continue;
      out.set(el, { el_nr: el, nrf_nr: null, gtin: null, name: null, price, unit });
    }
    return [...out.values()];
  }

  function ahlsellList(doc) {
    // Only electrical products: a VVS article number is not an EL number.
    if (!/^\/products\/elektro\//.test(doc.location?.pathname ?? "")) return [];
    const text = textOf(doc.body).replace(/\s+/g, " ").slice(0, 500_000);
    const PRICE = /^\s*\d{1,3}(?:[\s  .]\d{3})*,\d{2}\s*NOK\s*\/\s*[a-zæøå]+\s*$/i;
    const leaves = (root, re) => [...root.querySelectorAll("*")].filter((e) => e.children.length === 0 && re.test(e.textContent ?? ""));
    const rows = [];
    for (const p of leaves(doc.body, PRICE)) {
      if (p.closest("p.text-heading-h3")) continue; // the product's own price: read by the product page reader
      // The row: the nearest element around the price with exactly one article number, and one price.
      let row = p.parentElement;
      for (let i = 0; i < 8 && row && leaves(row, /^\s*\d{7}\s*$/).length === 0; i++) row = row.parentElement;
      if (!row) continue;
      const numbers = leaves(row, /^\s*\d{7}\s*$/);
      if (numbers.length !== 1 || leaves(row, PRICE).length !== 1) continue;
      rows.push({ elText: numbers[0].textContent, priceText: p.textContent });
    }
    return ahlsellListFromParts({
      signedIn: /mine sider/i.test(text) && /\(\s*\d{5,}\s*\)/.test(text) && !/logg inn for lagerstatus og pris/i.test(text),
      rows,
    });
  }

  /**
   * Onninen's category pages (checked 2026-11-18 on /elektro/diverse/c/NO_iStore_14.99.01, signed
   * in): each .product-card shows «Produktnummer 1430300» (the EL number, the same as the product
   * page's electCode), the company's price in .customer-price «92,92 kr / stk» (the same as the
   * product page) and «Listepris» beside it (not used). Only under /elektro/: elsewhere (VVS, search
   * results) the 7-digit «Produktnummer» can be an NRF number.
   */
  function onninenListFromParts({ signedIn, path, cards }) {
    if (!signedIn || !/^\/elektro\//.test(String(path ?? ""))) return [];
    const out = new Map();
    for (const c of cards ?? []) {
      const el = /^\s*(\d{7})\s*$/.exec(String(c?.codeText ?? ""))?.[1];
      const url = String(c?.href ?? "");
      if (!el || out.has(el) || !/^https:\/\/(?:www\.)?onninen\.no\/[^?#]*\/p\/[^/?#]+\/?$/.test(url)) continue;
      const price = money(c?.priceText);
      const unit = unitOf(c?.unitText);
      if (!price || !unit) continue;
      out.set(el, { el_nr: el, nrf_nr: null, gtin: null, name: String(c?.name ?? "").trim() || null, url, price, unit });
    }
    return [...out.values()];
  }

  function onninenList(doc) {
    const cards = [];
    for (const card of doc.querySelectorAll(".product-card")) {
      const codes = card.querySelectorAll(".value-copyable");
      const label = [...card.querySelectorAll("span")].some((s) => /^produktnummer$/i.test((s.textContent ?? "").trim()));
      const prices = card.querySelectorAll(".customer-price");
      const links = new Set([...card.querySelectorAll('a[href*="/p/"]')].map((a) => a.href));
      if (codes.length !== 1 || !label || prices.length !== 1 || links.size !== 1) continue;
      cards.push({
        codeText: codes[0].textContent,
        priceText: prices[0].querySelector(".number")?.textContent,
        unitText: prices[0].querySelector(".unit")?.textContent,
        href: [...links][0],
        name: card.querySelector(".test-product-title")?.textContent ?? "",
      });
    }
    return onninenListFromParts({
      signedIn: !!doc.querySelector(".desktop-customer-selector__label"),
      path: doc.location?.pathname ?? "",
      cards,
    });
  }

  // Host → list reader.
  const LIST_READERS = {
    "solarnorge.no": (doc) => solarCards(doc),
    "dahl.no": dahlList,
    "elektroimportoren.no": elektroimportorenList,
    "ahlsell.no": ahlsellList,
    "onninen.no": onninenList,
  };

  function listReaderFor(host) {
    const site = Object.keys(LIST_READERS).find((s) => host === s || host.endsWith("." + s));
    return site ? LIST_READERS[site] : null;
  }

  // Site (without www.) → reader. A site is added only after its pages have been checked with a
  // real account (signed in, and the price read is the company's net price excl. VAT).
  const READERS = {
    "onninen.no": onninen,
    "dahl.no": dahl,
    "elektroimportoren.no": elektroimportoren,
    "ahlsell.no": ahlsell,
    "solarnorge.no": solar,
    "malmbergs.com": malmbergs,
    "etman.no": etman,
    "eldirekte.no": eldirekte,
  };

  /** The reader for a host name, or null. */
  function readerFor(host) {
    const site = Object.keys(READERS).find((s) => host === s || host.endsWith("." + s));
    return site ? READERS[site] : null;
  }

  root.LMReaders = {
    textOf,
    productPage,
    priceFromBox,
    elektroimportoren,
    elektroimportorenFromParts,
    malmbergs,
    malmbergsFromParts,
    etman,
    etmanFromParts,
    eldirekte,
    eldirekteFromParts,
    onninenSpecEl,
    ahlsellFromParts,
    ahlsell,
    pieceFromName,
    withPieces,
    solarFromParts,
    solar,
    solarCardsFromParts,
    solarCards,
    dahlListFromParts,
    dahlList,
    elektroimportorenListFromParts,
    elektroimportorenList,
    ahlsellListFromParts,
    ahlsellList,
    onninenListFromParts,
    onninenList,
    listReaderFor,
    guessPrice,
    bestGuess,
    unitOf,
    onninenFromParts,
    dahlFromParts,
    onninen,
    dahl,
    readerFor,
    sites: () => Object.keys(READERS),
  };
})(globalThis);
