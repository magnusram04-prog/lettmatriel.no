// «Lag vareliste»: the assistant turns a job into a list of products. Prices and links come from the
// background page (lookup), so each product shows the company's own prices, cheapest wholesaler first.
(function () {
  const $ = (id) => document.getElementById(id);
  const P = globalThis.LMPrices;
  const { parseVariant } = globalThis.LM_VARIANT;
  // A failed message is answered as { error }, so the callers only have to check for that.
  const send = (message) => chrome.runtime.sendMessage(message).catch((e) => ({ error: String(e?.message ?? e) }));

  // Wholesaler slug (as in the offers) → its domain, and the domain → its name.
  const SITE_BY_SLUG = {
    ahlsell: "ahlsell.no",
    "ahlsell-vvs": "ahlsell.no",
    "brodrene-dahl": "dahl.no",
    onninen: "onninen.no",
    solar: "solarnorge.no",
    heidenreich: "heidenreich.no",
    "berggard-amundsen": "berggardamundsen.no",
    elektroimportoren: "elektroimportoren.no",
  };
  const NAME_BY_SITE = {
    "ahlsell.no": "Ahlsell",
    "dahl.no": "Brødrene Dahl",
    "onninen.no": "Onninen",
    "solarnorge.no": "Solar",
    "heidenreich.no": "Heidenreich",
    "berggardamundsen.no": "Berggård Amundsen",
    "elektroimportoren.no": "Elektroimportøren",
  };

  // The conversation with the assistant, and the product list it has made.
  let messages = [];
  let items = [];

  /** An element. Text is always set as text, never read as HTML. Arrays among the children are flattened. */
  function h(tag, props = {}, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === "class") node.className = v;
      else if (k === "on") for (const [ev, fn] of Object.entries(v)) node.addEventListener(ev, fn);
      else if (k in node) node[k] = v;
      else node.setAttribute(k, v);
    }
    node.append(...children.flat().filter((c) => c != null && c !== false));
    return node;
  }

  // Only https links are shown: a link text comes from the database and must not be a script.
  const httpsUrl = (u) => (typeof u === "string" && /^https:\/\//.test(u) ? u : null);
  const linkTo = (url, text) => (url ? h("a", { href: url, target: "_blank", rel: "noopener" }, text) : null);
  const wholesalerName = (o) => String(o.wholesaler_name ?? o.wholesaler ?? "").trim();
  // The price used: the chosen wholesaler's, else the cheapest one (offers are sorted, current prices first).
  const chosenOffer = (item) => item.offers.find((o) => o.wholesaler === item.wholesaler) ?? item.offers[0] ?? null;
  const linkFor = (item, offer) =>
    httpsUrl(offer.product_url ?? item.links.find((l) => l.site === SITE_BY_SLUG[offer.wholesaler])?.url);

  function toItem(it) {
    const qty = Number(it.qty);
    return {
      name: String(it.name ?? ""),
      elNr: it.elNr ? String(it.elNr) : null,
      unit: String(it.unit ?? ""),
      qty: Number.isFinite(qty) && it.qty !== null ? qty : 1,
      note: String(it.note ?? ""),
      variantQuery: String(it.variantQuery || it.name || ""),
      offers: [],
      links: [],
      wholesaler: null,
      loading: true,
      error: null,
      open: false,
      variants: null,
      sel: null,
      variantMsg: "",
      row: null,
    };
  }

  /** The row of one product. Put in place of the old row, so a price arriving does not reset the others. */
  function paint(item) {
    const row = itemRow(item);
    if (item.row) item.row.replaceWith(row);
    else $("items").append(row);
    item.row = row;
    updateTotal();
  }

  function itemRow(item) {
    const offer = chosenOffer(item);
    return h("li", { class: "item" },
      h("div", { class: "line" },
        h("input", {
          class: "qty", type: "number", min: "0", step: "1", value: item.qty, "aria-label": `Antall ${item.name}`,
          on: { input: (e) => { item.qty = e.target.value; updateTotal(); } },
        }),
        h("span", { class: "unit" }, item.unit),
        h("div", { class: "what" },
          h("strong", {}, item.name),
          h("small", { class: "muted" }, [item.elNr ? `EL-nr ${item.elNr}` : "Uten EL-nr", item.note].filter(Boolean).join(" · ")))),
      h("div", { class: "price" }, priceBox(item, offer)),
      h("button", { type: "button", class: "plain", on: { click: () => toggleVariant(item) } },
        item.open ? "Skjul variant" : "Velg variant"),
      item.open ? variantPanel(item) : null);
  }

  function priceBox(item, offer) {
    if (item.loading) return h("span", { class: "muted" }, "Henter pris …");
    if (!offer) {
      return h("div", {},
        item.error
          ? h("span", { class: "error" }, item.error)
          : h("span", { class: "muted" }, "Ingen pris ennå. Åpne varen hos grossisten, så lagres prisen."),
        item.links.map((l) => linkTo(httpsUrl(l.url), `Se varen hos ${NAME_BY_SITE[l.site] ?? l.site}`)));
    }
    return h("div", {},
      h("span", { class: offer.old ? "num old" : "num" },
        P.formatPerUnit(Number(offer.net_per_measure_unit), P.unitName(offer.measure_unit))),
      " ",
      h("span", { class: "muted" }, `${wholesalerName(offer)}, ${P.priceDate(offer)}`),
      offer.old ? h("span", { class: "tag" }, "gammel pris") : null,
      h("div", {}, linkTo(linkFor(item, offer), `Åpne hos ${wholesalerName(offer)}`)));
  }

  /** The variant choice: wholesaler, brand, colour and mounting. Brand, colour and mounting come from the catalogue. */
  function variantPanel(item) {
    if (item.variants?.error) return h("div", { class: "variant" }, h("p", { class: "error" }, item.variants.error));
    if (!item.variants) return h("div", { class: "variant muted" }, "Henter varianter …");
    const { rows } = item.variants;
    if (rows.length === 0) return h("div", { class: "variant muted" }, "Ingen varianter funnet.");
    const select = (label, value, opts, onChange) =>
      h("label", { class: "field" }, label,
        h("select", { on: { change: (e) => onChange(e.target.value) } },
          opts.map(([v, text]) => h("option", { value: v, selected: v === value }, text))));
    const optionsFor = (key) => {
      const values = [...new Set(rows.map((r) => r.v[key]).filter(Boolean))].sort((a, b) => a.localeCompare(b, "nb"));
      return [["", "Alle"], ...values.map((v) => [v, v])];
    };
    return h("div", { class: "variant" },
      item.offers.length
        ? select("Grossist", chosenOffer(item)?.wholesaler ?? "",
          item.offers.map((o) => [o.wholesaler, wholesalerName(o)]),
          (v) => { item.wholesaler = v; paint(item); })
        : null,
      [["merke", "Merke"], ["farge", "Farge"], ["montering", "Montering"]].map(([key, label]) =>
        select(label, item.sel[key], optionsFor(key), (v) => { item.sel[key] = v; chooseVariant(item); })),
      item.variantMsg ? h("p", { class: "error" }, item.variantMsg) : null);
  }

  async function toggleVariant(item) {
    item.open = !item.open;
    paint(item);
    if (item.open && !item.variants) {
      await loadVariants(item);
      paint(item);
    }
  }

  async function loadVariants(item) {
    const res = await send({ type: "catalogSearch", query: item.variantQuery });
    if (!Array.isArray(res)) {
      item.variants = { error: res?.error ?? "Kunne ikke hente varianter." };
      return;
    }
    const rows = res.map((r) => ({ el_nr: r.el_nr, name: r.name, v: parseVariant(r.name) }));
    // The choice starts at the product's own values («Alle» where the catalogue has none of them).
    const own = parseVariant(item.name);
    item.sel = Object.fromEntries(["merke", "farge", "montering"].map((k) =>
      [k, rows.some((r) => r.v[k] === own[k]) ? own[k] : ""]));
    item.variants = { rows };
    item.variantMsg = "";
  }

  const fits = (v, sel) => ["merke", "farge", "montering"].every((k) => !sel[k] || v[k] === sel[k]);

  /** The first catalogue product that has all the chosen values; its name and EL number replace the product's. */
  async function chooseVariant(item) {
    const hit = item.variants.rows.find((r) => fits(r.v, item.sel));
    item.variantMsg = hit ? "" : "Ingen vare med akkurat det valget.";
    if (hit && hit.el_nr !== item.elNr) {
      item.elNr = hit.el_nr;
      item.name = hit.name;
      item.loading = true;
      paint(item);
      await loadPrice(item);
    } else {
      paint(item);
    }
  }

  /** Prices and links of one product (lookup in the background page). Wholesalers switched off are left out. */
  async function loadPrice(item) {
    const elNr = item.elNr;
    item.loading = true;
    const res = elNr ? await send({ type: "lookup", product: { elNr }, shops: false }) : {};
    if (item.elNr !== elNr) return; // the product was changed meanwhile: its own answer comes later
    const { disabledSites = [] } = await chrome.storage.local.get("disabledSites");
    const off = new Set(disabledSites);
    const offers = (res?.offers ?? []).filter((o) => !off.has(SITE_BY_SLUG[o.wholesaler]));
    item.offers = P.pickOffers(offers, Date.now());
    item.links = (res?.links ?? []).filter((l) => !off.has(l.site));
    item.error = res?.error ?? null;
    item.wholesaler = item.offers.some((o) => o.wholesaler === item.wholesaler)
      ? item.wholesaler
      : (item.offers[0]?.wholesaler ?? null);
    item.loading = false;
    paint(item);
  }

  /** Prices for all products, five at a time. */
  async function loadAll(list) {
    let next = 0;
    const worker = async () => {
      while (next < list.length) await loadPrice(list[next++]);
    };
    await Promise.all(Array.from({ length: Math.min(5, list.length) }, worker));
  }

  function updateTotal() {
    const sum = items.reduce((s, item) => {
      const offer = chosenOffer(item);
      return offer ? s + (Number(item.qty) || 0) * Number(offer.net_per_measure_unit) : s;
    }, 0);
    $("total").textContent = P.formatKr(sum);
  }

  function setError(text) {
    $("error").textContent = text;
    $("error").hidden = !text;
  }

  function setBusy(on) {
    $("status").hidden = !on;
    $("send").disabled = on;
    $("answer-send").disabled = on;
  }

  /** Shows the assistant's answer: its text, its question (if any) and the product list (if any). */
  function show(res) {
    $("reply").textContent = res.reply ?? "";
    $("reply").hidden = !res.reply;
    $("question").hidden = !res.question;
    $("question-text").textContent = res.question ?? "";
    const p = res.proposal;
    $("result").hidden = !p;
    if (!p) return;
    items = (p.items ?? []).map(toItem);
    $("items").replaceChildren();
    for (const item of items) paint(item);
    updateTotal();
    const missing = p.missing ?? [];
    $("missing").textContent = `Fant ikke: ${missing.join(", ")}`;
    $("missing").hidden = missing.length === 0;
    loadAll(items);
  }

  /** Sends the conversation with one more message. The text stays in the field when the answer fails. */
  async function ask(text, field) {
    setError("");
    const sent = [...messages, { role: "user", content: text }];
    setBusy(true);
    const res = await send({ type: "vareliste", messages: sent });
    setBusy(false);
    if (!res || res.error) {
      setError(res?.error ?? "Fikk ikke svar. Prøv igjen.");
      return;
    }
    const said = [...new Set([res.reply, res.question].filter(Boolean))].join("\n") || "Lista er oppdatert.";
    messages = [...sent, { role: "assistant", content: said }];
    field.value = "";
    show(res);
  }

  $("ask").addEventListener("submit", (e) => {
    e.preventDefault();
    const text = $("job").value.trim();
    // A new description is a new list; only the answer field continues the conversation.
    if (text) { messages = []; ask(text, $("job")); }
  });

  $("answer-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const text = $("answer").value.trim();
    if (text) ask(text, $("answer"));
  });

  for (const b of document.querySelectorAll("[data-example]")) {
    b.addEventListener("click", () => {
      $("job").value = b.dataset.example;
      $("job").focus();
    });
  }

  $("copy").addEventListener("click", async () => {
    const lines = items.filter((i) => Number(i.qty) > 0).map((i) => [i.elNr ?? "", i.qty, i.name].join("\t"));
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      $("copied").textContent = "Kopiert";
    } catch {
      $("copied").textContent = "Kunne ikke kopiere.";
    }
  });
})();
