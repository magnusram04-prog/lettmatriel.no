// Talks to LettMateriell's database for the popup and the product pages.
// The extension has its own sign-in (its own session), so it never touches the
// website's session; the session is kept in the extension's storage only.
importScripts("config.js");

const { supabaseUrl, supabaseKey } = globalThis.LM_CONFIG;
const DAY = 24 * 60 * 60 * 1000;

function toSession(j) {
  return {
    access_token: j.access_token,
    refresh_token: j.refresh_token,
    expires_at: j.expires_at ?? Math.floor(Date.now() / 1000) + (j.expires_in ?? 3600),
    email: j.user?.email ?? null,
  };
}

async function authRequest(grant, body) {
  const r = await fetch(`${supabaseUrl}/auth/v1/token?grant_type=${grant}`, {
    method: "POST",
    headers: { apikey: supabaseKey, "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const j = await r.json().catch(() => ({}));
  return { ok: r.ok, status: r.status, j };
}

async function signIn(email, password) {
  const { ok, j } = await authRequest("password", { email, password });
  if (!ok) {
    const msg = j.error_code === "invalid_credentials" || j.error === "invalid_grant"
      ? "Feil e-post eller passord."
      : j.msg ?? j.error_description ?? "Kunne ikke logge inn.";
    throw new Error(msg);
  }
  const session = toSession(j);
  await chrome.storage.local.set({ session });
  const { pendingCompany } = await chrome.storage.local.get("pendingCompany");
  const res = await joinCompany(session, pendingCompany?.name, pendingCompany?.orgNr);
  if (!res.needsCompany) await chrome.storage.local.remove("pendingCompany");
  return { email: session.email, ...res };
}

/** The user's company; asked again (without making one) when not known yet, e.g. after an update. */
async function currentCompany(session) {
  const { company } = await chrome.storage.local.get("company");
  if (company) return { company };
  try {
    return await joinCompany(session, null, null);
  } catch {
    // Not known right now (e.g. offline): not the same as having no company.
    return { company: null };
  }
}

/**
 * Into a company: an invitation, else colleagues with the same work e-mail domain,
 * else a new company, which needs a name and an organisation number from the first user.
 */
async function joinCompany(session, name, orgNr) {
  try {
    const rows = await api("/rest/v1/rpc/join_company_by_email", session, {
      method: "POST",
      body: JSON.stringify({ p_name: name || null, p_org_nr: orgNr || null }),
    });
    const company = rows?.[0] ? { name: rows[0].tenant_name, joined: rows[0].joined } : null;
    await chrome.storage.local.set({ company });
    return { company };
  } catch (e) {
    await chrome.storage.local.set({ company: null });
    if (e.hint === "needs_company") return { company: null, needsCompany: e.message };
    throw e;
  }
}

/** A new account. Supabase sends a confirmation link; the user signs in after clicking it. */
async function signUp(email, password, companyName, orgNr) {
  const r = await fetch(
    `${supabaseUrl}/auth/v1/signup?redirect_to=${encodeURIComponent(globalThis.LM_CONFIG.siteUrl)}`,
    {
      method: "POST",
      headers: { apikey: supabaseKey, "content-type": "application/json" },
      body: JSON.stringify({ email, password }),
    },
  );
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const msg = j.error_code === "user_already_exists"
      ? "Det finnes allerede en konto med denne e-posten. Logg inn i stedet."
      : j.error_code === "weak_password"
      ? "Passordet er for svakt. Bruk minst 8 tegn."
      : j.error_code === "over_email_send_rate_limit"
      ? "For mange forsøk på kort tid. Vent litt og prøv igjen."
      : j.msg ?? "Kunne ikke opprette konto.";
    throw new Error(msg);
  }
  // Supabase answers a sign-up for an existing address with a user without identities.
  if (Array.isArray(j.identities) && j.identities.length === 0) {
    throw new Error("Det finnes allerede en konto med denne e-posten. Logg inn i stedet.");
  }
  // Used as the company's name if this is the first user from the company.
  if (companyName || orgNr) await chrome.storage.local.set({ pendingCompany: { name: companyName, orgNr } });
  return {};
}

async function signOut() {
  const { session } = await chrome.storage.local.get("session");
  await chrome.storage.local.remove(["session", "company"]);
  if (session) {
    // Only this extension's session; the website and other devices stay signed in.
    await fetch(`${supabaseUrl}/auth/v1/logout?scope=local`, {
      method: "POST",
      headers: { apikey: supabaseKey, authorization: `Bearer ${session.access_token}` },
    }).catch(() => {});
  }
}

let refreshing = null;

/** A valid session, refreshed when it is about to expire; null when signed out. */
async function getSession() {
  const { session } = await chrome.storage.local.get("session");
  if (!session) return null;
  if (session.expires_at * 1000 - Date.now() > 60_000) return session;
  // One refresh at a time: a refresh token can be used only once.
  refreshing ??= (async () => {
    try {
      const { ok, status, j } = await authRequest("refresh_token", { refresh_token: session.refresh_token });
      if (ok) {
        const next = { ...toSession(j), email: j.user?.email ?? session.email };
        await chrome.storage.local.set({ session: next });
        return next;
      }
      // A refused token means signed out; a network error keeps the session for later.
      if (status === 400 || status === 401) await chrome.storage.local.remove("session");
      return null;
    } finally {
      refreshing = null;
    }
  })();
  return refreshing;
}

async function api(path, session, init = {}) {
  const r = await fetch(`${supabaseUrl}${path}`, {
    ...init,
    headers: {
      apikey: supabaseKey,
      authorization: `Bearer ${session.access_token}`,
      "content-type": "application/json",
      ...init.headers,
    },
  });
  if (!r.ok) {
    const j = await r.json().catch(() => ({}));
    throw Object.assign(new Error(j.message ?? `Feil fra LettMateriell (${r.status})`), { hint: j.hint, code: j.code });
  }
  return r.status === 204 ? null : r.json();
}

/** PostgREST filter matching any of the product's numbers (digits only, so safe to put in the URL). */
function numberFilter(p) {
  const parts = [];
  if (/^\d{7}$/.test(p.elNr ?? "")) parts.push(`el_nr.eq.${p.elNr}`);
  if (/^\d{7}$/.test(p.nrfNr ?? "")) parts.push(`nrf_nr.eq.${p.nrfNr}`);
  if (/^\d{8,14}$/.test(p.gtin ?? "")) parts.push(`gtin.eq.${p.gtin}`);
  return parts.length ? `or=(${parts.join(",")})` : null;
}

// Answers kept for a short while: going back and forth between pages asks the database only once.
const cache = new Map();
const LOOKUP_TTL = 30_000;
const LINKS_TTL = 60_000;

function cached(key, ttl, load) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttl) return hit.value;
  const value = load();
  cache.set(key, { at: Date.now(), value });
  // A failed request is not kept.
  Promise.resolve(value).catch(() => cache.delete(key));
  if (cache.size > 200) cache.delete(cache.keys().next().value);
  return value;
}

/** Prices changed: the next lookup asks the database again. */
function forgetLookups() {
  for (const key of [...cache.keys()]) if (key.startsWith("lookup|")) cache.delete(key);
}

/** Where a product has been seen, by any company: addresses only, never prices. */
function catalogLinks(session, elNr) {
  if (!/^\d{7}$/.test(elNr ?? "")) return Promise.resolve([]);
  return cached(`links|${elNr}`, LINKS_TTL, () =>
    api("/rest/v1/rpc/catalog_links", session, { method: "POST", body: JSON.stringify({ p_el_nr: elNr }) }));
}

async function lookup(product, withShops) {
  const session = await getSession();
  if (!session) return { signedIn: false };
  const filter = numberFilter(product);
  if (!filter) return { signedIn: true, offers: [], shops: [] };
  return cached(`lookup|${session.email}|${filter}|${withShops}`, LOOKUP_TTL, () =>
    askLookup(session, product, filter, withShops));
}

// The columns of v_price_comparison that the panel reads. A database may not have some of them yet
// (as_of, product_url): it then answers that the column does not exist (42703), and that column is
// left out of the questions from then on, so the prices still come (without the missing column).
const PRICE_COLUMNS = [
  "product_name",
  "wholesaler",
  "wholesaler_name",
  "net_per_measure_unit",
  "measure_unit",
  "net_source",
  "seen_at",
  "as_of",
  "product_url",
];
const missingColumns = new Set();

/** The offers of a product from the view: one row per price (the panel picks one per wholesaler). */
async function priceRows(session, filter) {
  for (;;) {
    const columns = PRICE_COLUMNS.filter((c) => !missingColumns.has(c));
    try {
      return await api(
        `/rest/v1/v_price_comparison?select=${columns.join(",")}&${filter}&order=net_per_measure_unit.asc&limit=40`,
        session,
      );
    } catch (e) {
      const gone = e?.code === "42703" ? columns.find((c) => String(e.message).includes(`.${c} `)) : undefined;
      if (!gone) throw e;
      missingColumns.add(gone);
    }
  }
}

async function askLookup(session, product, filter, withShops) {
  const since = new Date(Date.now() - 90 * DAY).toISOString();
  const [rows, shops, links, deals] = await Promise.all([
    priceRows(session, filter),
    // Shop prices only matter in shops.
    withShops
      ? api(
        `/rest/v1/market_prices?select=shop,price,seen_at&${filter}&seen_at=gte.${encodeURIComponent(since)}&order=seen_at.desc&limit=50`,
        session,
      )
      : [],
    catalogLinks(session, product.elNr).catch(() => []),
    allDeals(session).catch(() => []),
  ]);
  // All the prices, cheapest first. The panel picks one per wholesaler and leaves out old prices
  // (extension/prices.js), so an old cheap price never hides a current one.
  const offers = rows ?? [];
  // The newest price per shop.
  const latest = [];
  for (const s of shops) {
    if (!latest.some((x) => x.shop === s.shop)) latest.push(s);
  }
  // Campaigns on this product at the wholesalers (read every night from their campaign pages).
  const productDeals = (deals ?? []).filter((d) => d.el_nr && d.el_nr === product.elNr);
  return {
    signedIn: true,
    email: session.email,
    offers,
    shops: latest,
    links: links ?? [],
    deals: productDeals,
    tester: await isTester(session),
  };
}

async function record(p) {
  const session = await getSession();
  if (!session) return;
  await api("/rest/v1/rpc/record_market_price", session, {
    method: "POST",
    body: JSON.stringify({
      p_shop: p.shop,
      p_url: p.url,
      p_el_nr: p.elNr,
      p_nrf_nr: p.nrfNr,
      p_gtin: p.gtin,
      p_name: p.name,
      p_price: p.price,
    }),
  });
  forgetLookups();
}

/** Whether prices seen on the wholesalers' sites are saved (on unless switched off). */
async function captureOn() {
  const { capture } = await chrome.storage.local.get("capture");
  return capture !== false;
}

async function recordWholesaler(m) {
  if (!(await captureOn())) return { saved: 0 };
  const session = await getSession();
  if (!session || !Array.isArray(m.items) || m.items.length === 0) return { saved: 0 };
  const saved = await api("/rest/v1/rpc/record_wholesaler_prices", session, {
    method: "POST",
    body: JSON.stringify({ p_site: String(m.site ?? ""), p_url: String(m.url ?? ""), p_items: m.items.slice(0, 200) }),
  });
  forgetLookups(); // the bubble must show the price just saved
  const first = Number(saved) > 0 ? await firstSave(String(m.site ?? ""), m.items) : false;
  return { saved, first };
}

// Products whose price this browser has saved from a site («onninen.no|1410221|null|…»): the first
// time, the bubble opens by itself so the user sees the price was saved.
const SAVED_KEY = "savedPrices";
const SAVED_MAX = 20_000;

async function firstSave(site, items) {
  const key = `${site.replace(/^www\./, "")}|${items[0]?.el_nr ?? null}|${items[0]?.nrf_nr ?? null}|${items[0]?.gtin ?? null}`;
  const { [SAVED_KEY]: list = [] } = await chrome.storage.local.get(SAVED_KEY);
  if (list.includes(key)) return false;
  list.push(key);
  await chrome.storage.local.set({ [SAVED_KEY]: list.slice(-SAVED_MAX) });
  return true;
}

// Whether the signed-in user is a tester, asked once per session of the worker.
let testerFor = null;
let tester = false;

async function isTester(session) {
  if (testerFor !== session.email) {
    tester = (await api("/rest/v1/rpc/is_tester", session, { method: "POST", body: "{}" }).catch(() => false)) === true;
    testerFor = session.email;
  }
  return tester;
}

// Products the catalogue already has from a site (by anyone), so they are not sent again.
const KNOWN_KEY = "knownNumbers";
const KNOWN_MAX = 50_000;

// Held in memory as a Set (fast to look up); written to storage a moment after changes.
let knownSet = null;
let saveTimer = null;

async function knownNumbers() {
  if (!knownSet) {
    const { [KNOWN_KEY]: known = [] } = await chrome.storage.local.get(KNOWN_KEY);
    knownSet = new Set(known);
  }
  return knownSet;
}

async function remember(keys) {
  const known = await knownNumbers();
  for (const k of keys) {
    known.delete(k); // newest last, so the oldest are dropped first
    known.add(k);
  }
  while (known.size > KNOWN_MAX) known.delete(known.values().next().value);
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => chrome.storage.local.set({ [KNOWN_KEY]: [...known] }), 1000);
}

/**
 * An electrical product opened on a wholesaler's site. All users fill the catalogue together:
 * it is sent only if the catalogue does not have it from this wholesaler yet.
 */
async function viewed(m) {
  const session = await getSession();
  if (!session) return {};
  const p = m.product ?? {};
  // Only products with both an EL number and an EAN.
  if (!/^\d{7}$/.test(p.elNr ?? "") || !/^\d{8,14}$/.test(p.gtin ?? "")) return {};
  const site = String(p.site ?? "").replace(/^www\./, "");
  const keyFor = (s) => `${s}|${p.elNr}`;
  const key = keyFor(site);
  if ((await knownNumbers()).has(key)) return { skipped: true };
  // Ask first: which wholesalers the catalogue already has this product from
  // (the same answer the price bubble asks for, so it is fetched only once).
  const sites = (await catalogLinks(session, p.elNr)).map((l) => l.site);
  if (Array.isArray(sites) && sites.includes(site)) {
    await remember(sites.map(keyFor));
    return { skipped: true };
  }
  await api("/rest/v1/rpc/record_viewed_product", session, {
    method: "POST",
    body: JSON.stringify({
      p_site: site,
      p_url: String(p.url ?? ""),
      p_el_nr: p.elNr,
      p_nrf_nr: p.nrfNr ?? null,
      p_gtin: p.gtin,
      p_name: p.name ?? null,
    }),
  });
  await remember([key, ...sites.map(keyFor)]);
  cache.delete(`links|${p.elNr}`); // the catalogue now has this wholesaler too
  return { saved: true };
}

const DEALS_TTL = 60 * 60_000; // they change once a night

/** Today's deals from the wholesalers' campaign pages, the company's own products first. */
function allDeals(session) {
  return cached(`deals|${session.email}`, DEALS_TTL, () => api("/rest/v1/rpc/my_deals", session, { method: "POST", body: "{}" }));
}

const handlers = {
  deals: async () => {
    const session = await getSession();
    if (!session) return { signedIn: false, deals: [] };
    return { signedIn: true, deals: await allDeals(session) };
  },
  status: async () => {
    const session = await getSession();
    return {
      email: session?.email ?? null,
      capture: await captureOn(),
      tester: session ? await isTester(session) : false,
      ...(session ? await currentCompany(session) : { company: null }),
    };
  },
  setCapture: async (m) => {
    await chrome.storage.local.set({ capture: !!m.on });
    return {};
  },
  recordWholesaler,
  viewed,
  signIn: (m) => signIn(String(m.email ?? "").trim(), String(m.password ?? "")),
  setupCompany: async (m) => {
    const session = await getSession();
    if (!session) throw new Error("Logg inn på nytt.");
    return joinCompany(session, String(m.name ?? "").trim(), String(m.orgNr ?? "").replace(/\s/g, ""));
  },
  signUp: (m) =>
    signUp(
      String(m.email ?? "").trim(),
      String(m.password ?? ""),
      String(m.company ?? "").trim() || null,
      String(m.orgNr ?? "").replace(/\s/g, "") || null,
    ),
  signOut: () => signOut().then(() => ({})),
  lookup: (m) => lookup(m.product ?? {}, m.shops !== false),
  record: (m) => record(m.product ?? {}).then(() => ({})),
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Only this extension's own pages and content scripts can send messages here.
  if (sender.id !== chrome.runtime.id) return false;
  const handler = handlers[message?.type];
  if (!handler) return false;
  handler(message).then(sendResponse, (e) => sendResponse({ error: String(e?.message ?? e) }));
  return true; // answer asynchronously
});

// The welcome page with how to use the extension, opened once when it is installed.
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
});
