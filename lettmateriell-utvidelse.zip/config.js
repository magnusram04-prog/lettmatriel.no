// Public settings, the same the website uses. The key is public by design:
// what a signed-in user may see is decided by the database rules.
globalThis.LM_CONFIG = {
  supabaseUrl: "https://afhiqccalddlfvmxjivs.supabase.co",
  supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFmaGlxY2NhbGRkbGZ2bXhqaXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI3NjQ5MTcsImV4cCI6MjEwODM0MDkxN30.yoEjcHJkRbF5asmTSjtvmkcM8sG5DjyXKw3zx15zQRg",
  siteUrl: "https://lettmateriell.no/",
};
