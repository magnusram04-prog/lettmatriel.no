// Reads the brand, colour and mounting from a product name, e.g. «Elko Plus Stikkontakt Dobbel Innfelt Jord Polarhvit».
// Used by the product list (vareliste.js) to offer the variants of a product. Case does not matter.
(function (root) {
  // A word as it is written in a name: not part of a longer word. Norwegian letters count as letters.
  const word = (w) => new RegExp(`(?<![a-zæøå])(?:${w})(?![a-zæøå])`);

  // The brand as the maker writes it, and the words that name it in a product name.
  const MERKER = [
    ["Elko", word("elko")],
    ["Schneider", word("schneider")],
    ["Namron", word("namron")],
    ["Gira", word("gira")],
    ["Jung", word("jung")],
    ["Hager", word("hager")],
    ["ABB", word("abb")],
    ["Busch-Jaeger", word("busch[ -]?jaeger")],
    ["Legrand", word("legrand")],
    ["Eaton", word("eaton")],
    ["Malmbergs", word("malmbergs")],
    ["Opus", word("opus")],
    ["Impressivo", word("impressivo")],
    ["SG", word("sg")],
    ["Hide-a-lite", word("hide[ -]?a[ -]?lite")],
    ["Nexans", word("nexans")],
    ["Draka", word("draka")],
    ["Wago", word("wago")],
    ["Thorn", word("thorn")],
    ["Philips", word("philips")],
  ];

  // The first colour found counts: «matt sort» before «sort», and «polarhvit» before «hvit».
  const FARGER = [
    ["Polarhvit", word("polarhvit")],
    ["Hvit", word("hvit(?:t)?")],
    ["Matt sort", word("matt (?:sort|svart)")],
    ["Sort", word("sort|svart")],
    ["Grå", word("grå(?:tt)?")],
    ["Antrasitt", word("antrasitt")],
    ["Aluminium", word("aluminium")],
    ["Stål", word("stål")],
    ["Krom", word("krom")],
    ["Messing", word("messing")],
  ];

  function parseVariant(name) {
    const s = String(name ?? "").toLowerCase();
    const first = (list) => list.find(([, re]) => re.test(s))?.[0] ?? "";
    return {
      merke: first(MERKER) || "Annet",
      farge: first(FARGER),
      montering: /innfelt/.test(s) ? "Innfelt" : /påvegg|utenpå|\butv(?:endig)?\b/.test(s) ? "Påvegg" : "",
    };
  }

  root.LM_VARIANT = { parseVariant };
  if (typeof module !== "undefined") module.exports = { parseVariant };
})(globalThis);
