// Pure helpers for the prices in the extension's panel: how old a price is, the
// date written beside it, which prices count, and how a price is written. No
// browser or network calls here, so they can be tested (tests/extension_prices_test.ts).
(function (root) {
  const DAY = 24 * 60 * 60 * 1000;

  /**
   * A price older than this does not count for «billigst», «Billigst her ✓», the saving
   * «X kr/stk billigere hos Y» or «Du sparer N %». It is shown at the bottom, greyed.
   */
  const MAX_AGE_DAYS = 60;

  /** The measure units of v_price_comparison, as written after a price. */
  const UNITS = { 1: "stk", 2: "m", 3: "l", 4: "kg" };

  /** «stk», «m» …; "" for a unit that is not known. */
  function unitName(code) {
    return UNITS[String(code ?? "")] ?? "";
  }

  /**
   * The calendar day («2026-10-27», also at the start of a timestamp) as ms at UTC
   * midnight; null when the text is not a real day (e.g. 30 February).
   */
  function dayOf(value) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(value ?? ""));
    if (!m) return null;
    const y = Number(m[1]);
    const mo = Number(m[2]);
    const d = Number(m[3]);
    const ms = Date.UTC(y, mo - 1, d);
    const back = new Date(ms);
    // Date.UTC rolls a day such as 30 February over into March.
    return back.getUTCFullYear() === y && back.getUTCMonth() === mo - 1 && back.getUTCDate() === d ? ms : null;
  }

  /** The date a price is from: when its price file was updated (as_of), else when it was seen on the site (seen_at). */
  function dateOf(row) {
    return row?.as_of ?? row?.seen_at ?? null;
  }

  /** Whole days from the price's date to today (now, in ms); null when the date is not known. */
  function ageDays(value, now = Date.now()) {
    const day = dayOf(value);
    if (day === null) return null;
    const n = new Date(now);
    const today = Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate());
    return Math.round((today - day) / DAY);
  }

  /**
   * Whether a price counts: its date is known and at most MAX_AGE_DAYS old. A price
   * without a known date does not count either; it is shown as «dato ukjent».
   */
  function isCurrent(row, now = Date.now()) {
    // A price-file price (no seen_at) is the company's current price list, whatever
    // its date: only prices seen on the wholesalers' sites grow old.
    if (!row?.seen_at) return true;
    const age = ageDays(dateOf(row), now);
    return age !== null && age <= MAX_AGE_DAYS;
  }

  /** «27.10.» for «2026-10-27»; null when the date is not known. */
  function shortDate(value) {
    const day = dayOf(value);
    if (day === null) return null;
    const d = new Date(day);
    return `${String(d.getUTCDate()).padStart(2, "0")}.${String(d.getUTCMonth() + 1).padStart(2, "0")}.`;
  }

  /** «sett 27.10.» for a price seen on the wholesaler's site, «prisfil 27.10.» for one from a price file. */
  function priceDate(row) {
    const kind = row?.seen_at ? "sett" : "prisfil";
    const day = shortDate(dateOf(row));
    return day ? `${kind} ${day}` : `${kind}, dato ukjent`;
  }

  const price = (o) => Number(o.net_per_measure_unit);

  /** Of two offers from one wholesaler: a current price beats an old one, then the lower price. */
  function beats(a, b) {
    if (a.old !== b.old) return !a.old;
    return price(a) < price(b);
  }

  /**
   * The offers to show: one per wholesaler (the best by beats), current prices first and
   * each group by price. Every offer gets its age (null when unknown) and whether it is old.
   */
  function pickOffers(rows, now = Date.now()) {
    const best = new Map();
    for (const row of Array.isArray(rows) ? rows : []) {
      if (!row) continue;
      const offer = { ...row, age: ageDays(dateOf(row), now), old: !isCurrent(row, now) };
      const held = best.get(row.wholesaler);
      if (!held || beats(offer, held)) best.set(row.wholesaler, offer);
    }
    return [...best.values()].sort((a, b) => Number(a.old) - Number(b.old) || price(a) - price(b));
  }

  /** «4,20» with two decimals, as written in Norway. */
  function formatNumber(n) {
    return Number(n).toLocaleString("nb-NO", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  /** «4,20 kr». */
  function formatKr(n) {
    return `${formatNumber(n)} kr`;
  }

  /** «4,20 kr/stk»: a price is always written with its unit (just «4,20 kr» when the unit is not known). */
  function formatPerUnit(n, unit) {
    return `${formatNumber(n)} kr${unit ? `/${unit}` : ""}`;
  }

  root.LMPrices = {
    MAX_AGE_DAYS,
    unitName,
    ageDays,
    isCurrent,
    shortDate,
    priceDate,
    pickOffers,
    formatKr,
    formatPerUnit,
  };
})(globalThis);
