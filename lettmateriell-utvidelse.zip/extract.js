// Reads product numbers and price from a product page. Pure functions on the
// page's JSON-LD and text, so they can be tested without a browser.
(function (root) {
  const digits = (s) => String(s ?? "").replace(/\D/g, "");

  /** GS1 check digit, so a random number on the page is not taken for an EAN. */
  function validGtin(code) {
    if (!/^(\d{8}|\d{12,14})$/.test(code)) return false;
    const d = code.split("").map(Number);
    const check = d.pop();
    const sum = d.reverse().reduce((s, n, i) => s + n * (i % 2 === 0 ? 3 : 1), 0);
    return (10 - (sum % 10)) % 10 === check;
  }

  /** "1 234,50", "1.234,50 kr", "129,-", 129.9 → number; anything else → null. */
  function parsePrice(v) {
    if (typeof v === "number") return v > 0 && v < 1e6 ? v : null;
    if (typeof v !== "string") return null;
    let s = v.replace(/kr|nok|,-|\s| /gi, "");
    if (/,\d{1,3}$/.test(s)) s = s.replace(/\./g, "").replace(",", ".");
    else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, ""); // «1.075,-»: a thousands dot
    else s = s.replace(/,/g, "");
    const n = Number(s);
    return Number.isFinite(n) && n > 0 && n < 1e6 ? n : null;
  }

  function collectProducts(node, out) {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) return node.forEach((n) => collectProducts(n, out));
    const types = [].concat(node["@type"] ?? []);
    if (types.includes("Product") || types.includes("ProductGroup")) out.push(node);
    if (node["@graph"]) collectProducts(node["@graph"], out);
  }

  /** From the page's <script type="application/ld+json"> blocks. */
  function fromJsonLd(texts) {
    const products = [];
    for (const t of texts) {
      try {
        collectProducts(JSON.parse(t), products);
      } catch {
        // A broken block is skipped.
      }
    }
    const p = products[0];
    if (!p) return {};
    const gtin = digits(p.gtin13 ?? p.gtin ?? p.gtin14 ?? p.gtin12 ?? p.gtin8);
    let price = null;
    for (const o of [].concat(p.offers ?? [])) {
      if (o.priceCurrency && o.priceCurrency !== "NOK") continue;
      price = parsePrice(o.price ?? o.lowPrice ?? o.priceSpecification?.price);
      if (price) break;
    }
    return {
      name: typeof p.name === "string" ? p.name.trim() : null,
      gtin: validGtin(gtin) ? gtin : null,
      price,
    };
  }

  const EL = /\bel[\s.\-]*(?:nr|nummer|no)\b\.?\s*:?\s*(\d{2}\s?\d{3}\s?\d{2})(?!\d)/i;
  const NRF = /\bnrf(?:[\s.\-]*(?:nr|nummer|no)\b)?\.?\s*:?\s*(\d{7})(?!\d)/i;
  // «Ean artikkelnr» is Ahlsell's label.
  const EAN = /\b(?:ean|gtin)(?:[\s.\-]*(?:kode|nr|nummer|code|artikkelnr|artikkelnummer))?\.?\s*:?\s*(\d{8}|\d{12,14})(?!\d)/i;

  /** From the visible text: «El.nr: 10 001 04», «NRF-nr 1234567», «EAN 7041234567890». */
  function fromText(text) {
    const el = text.match(EL);
    const nrf = text.match(NRF);
    const ean = text.match(EAN);
    return {
      elNr: el ? digits(el[1]) : null,
      nrfNr: nrf ? nrf[1] : null,
      gtin: ean && validGtin(ean[1]) ? ean[1] : null,
    };
  }

  /**
   * Numbers that only one site labels its own way. Ahlsell shows no «El.nr»:
   * on its electrical products the 7-digit «Artikkelnr» is the EL number.
   */
  function fromSite(host, path, text, scripts = "") {
    const inUrl = elFromUrl(host, path);
    if (inUrl) return { elNr: inUrl };
    if (/(^|\.)ahlsell\.no$/.test(host) && /^\/products\/elektro\//.test(path)) {
      const m = text.match(/\bartikkelnr\b\.?\s*:?\s*(\d{7})(?!\d)/i);
      if (m) return { elNr: m[1] };
    }
    // Etman: «Produktnummer: 1243876»; Eldirekte: «Varenummer: 1501362» (checked 2026-11-26: Norwegian
    // EL numbers, as at Onninen). Not «TP-45H»; never starting with 0.
    const own = /(^|\.)etman\.no$/.test(host) ? /\bproduktnummer\s*:?\s*([1-9]\d{6})(?!\d)/i
      : /(^|\.)eldirekte\.no$/.test(host) ? /\bvarenummer\s*:?\s*([1-9]\d{6})(?!\d)/i : null;
    if (own) {
      const m = text.match(own);
      return m ? { elNr: m[1] } : {};
    }
    // Onninen keeps the product's own EL number in the page data («electCode»). The
    // text can name other products' EL numbers first (accessories in the description).
    // Only the product whose «code» is the one in the address: after going to another product without
    // a page load, the page data can still hold the first one's.
    if (/(^|\.)onninen\.no$/.test(host)) {
      const code = String(path ?? "").match(/\/p\/([A-Za-z0-9_-]+)\/?$/)?.[1];
      const m = code && String(scripts ?? "").match(new RegExp(`"code"\\s*:\\s*"${code}"[^{}]*?"electCode"\\s*:\\s*"(\\d{7})"`, "i"));
      if (m) return { elNr: m[1] };
    }
    return {};
  }

  /**
   * The EL number in the page's address, on the sites that put it there. It is the
   * page's own product; the text can mention other products' EL numbers before it
   * («strekkavlaster … (el.nr. 1241000)» on another product's page).
   * Elektroimportøren: /<slug>/<EL>/Product.html. Berggård: /catalog/product/<slug>-<EL>.
   * Ahlsell: /products/elektro/…/<EL>---<slug>, or …/<EL> at the end.
   */
  function elFromUrl(host, path) {
    const p = String(path ?? "");
    let m = null;
    if (/(^|\.)elektroimportoren\.no$/.test(host)) m = p.match(/\/(\d{7})\/Product\.html$/i);
    else if (/(^|\.)berggardamundsen\.no$/.test(host)) m = p.match(/^\/catalog\/product\/.*-(\d{7})\/?$/);
    else if (/(^|\.)ahlsell\.no$/.test(host)) m = p.match(/^\/products\/elektro\/.*\/(\d{7})(?:---[^/]*)?\/?$/);
    // Malmbergs: /Products/<number>. Mostly Swedish E-numbers (0436602), some Norwegian EL numbers
    // (1018561 PFXP, as at Onninen); an EL number never starts with 0. Which is which: similarNames.
    else if (/(^|\.)malmbergs\.com$/.test(host)) m = p.match(/^\/Products\/([1-9]\d{6})\/?$/i);
    return m ? m[1] : null;
  }

  /**
   * Whether a wholesaler's page shows one product. Their category and search
   * pages list many, and the first number there is not the page's product.
   */
  function isProductPage(host, path, doc = null) {
    // Ahlsell: a product ends in its article number (…/1221903/ or …/4901203---varmevifte-2kw/); a
    // category under /products/ does not, and its text can name another product's EL number.
    if (/(^|\.)ahlsell\.no$/.test(host)) return /^\/products\/.*\/\d{7}(?:---[^/]*)?\/?$/.test(path);
    // Heidenreich: /produkt/<slug> (14 614 in its sitemap); categories are /kategori/….
    if (/(^|\.)heidenreich\.no$/.test(host)) return /^\/produkt\/[^/]+\/?$/.test(path);
    if (/(^|\.)onninen\.no$/.test(host)) return /\/p\/[^/]+\/?$/.test(path);
    if (/(^|\.)elektroimportoren\.no$/.test(host)) return /\/Product\.html$/i.test(path);
    if (/(^|\.)malmbergs\.com$/.test(host)) return /^\/Products\/\d+\/?$/i.test(path);
    // Etman: /product.vm?id=24104, or a name like /pfxp-fr-5g2-5mm-s100 that categories (/pfxp) also
    // have; only a product page has the price box .product-detail-price.
    if (/(^|\.)etman\.no$/.test(host)) {
      return /^\/product\.vm$/i.test(path) || !!doc?.querySelector?.(".product-detail-price");
    }
    if (/(^|\.)eldirekte\.no$/.test(host)) return /\/cat-p\//.test(path);
    // Dahl: …/<slug>-m3c_bd_<id>; Berggård: /catalog/product/<slug>-<EL> (as in the readers' notes).
    if (/(^|\.)dahl\.no$/.test(host)) return /-m3c_bd_[^/]+\/?$/i.test(path);
    if (/(^|\.)berggardamundsen\.no$/.test(host)) return /^\/catalog\/product\//.test(path);
    // Solar: …/no-webshop/<category>/<product id>/
    if (/(^|\.)solarnorge\.no$/.test(host)) return /^\/no-webshop\/.+\/\d{6,}\/?$/.test(path);
    return true;
  }

  /**
   * Whether a wholesaler's product is an electrical one. Ahlsell has
   * «/products/elektro/» in the address; Onninen's addresses do not say, but its
   * breadcrumb (Hjem > Elektro > …) links to «/elektro/…». Other sites: yes.
   */
  function isElektro(host, path, breadcrumbLinks) {
    if (/(^|\.)ahlsell\.no$/.test(host)) return path.startsWith("/products/elektro/");
    if (/(^|\.)onninen\.no$/.test(host)) return breadcrumbLinks.some((href) => /^\/elektro\//.test(href ?? ""));
    return true;
  }

  // Colours do not tell products apart («Stikkontakt hvit» is not «Bryter HVIT»).
  const COLOUR = /^(HVIT|HVITT|POLARHVIT|SVART|SVARTE|BRUN|GRØNN|SØLV|KROM|BEIGE|ROSA|LILLA|ORANSJE|TRANSPARENT|ANTRASITT)$/;

  /**
   * The words of a product name that tell products apart: «PFXP», «3G2,5» (also from «3G2,5mm2»),
   * «STIKKONTAKT»; not «16A», «IP68» or a colour.
   */
  function nameTokens(s) {
    return new Set(String(s ?? "").toUpperCase().split(/[^A-ZÆØÅ0-9,]+/)
      .map((t) => t.replace(/^,+|,+$/g, "").replace(/(\d)(MM2|MM)$/, "$1"))
      .filter((t) => t.length >= 4 && /[A-ZÆØÅ]/.test(t) && !/^(IP\d+|[\d,]+(V|A|W|MM2|MM|M|KV))$/.test(t) && !COLOUR.test(t)));
  }

  /**
   * Whether two names can be the same product: a model word in common (with a digit: «3G1,5», «RS16»), or
   * two other words. Malmbergs' 2403864 is a socket («Stikkontakt, rett, IP68»), at Onninen a cabinet kit
   * («SAMMENKOPL.SETT VEGGSKA»); «Vägguttag Optima» is not «LAMPEUTTAK OPTIMA». Kept the same as
   * private.similar_names in the database (migration 084).
   */
  function similarNames(a, b) {
    const A = nameTokens(a);
    const common = [...nameTokens(b)].filter((t) => A.has(t));
    return common.length >= 2 || common.some((t) => /\d/.test(t));
  }

  /** The first value found, in the order the sources are given. */
  function merge(...sources) {
    const pick = (k) => sources.map((s) => s?.[k]).find((v) => v != null && v !== "") ?? null;
    return { elNr: pick("elNr"), nrfNr: pick("nrfNr"), gtin: pick("gtin"), name: pick("name"), price: pick("price") };
  }

  root.LMExtract = { digits, validGtin, parsePrice, fromJsonLd, fromText, fromSite, elFromUrl, isProductPage, isElektro, merge, similarNames };
})(globalThis);
