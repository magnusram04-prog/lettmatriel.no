// Reads product numbers and price from a product page. Pure functions on the
// page's JSON-LD and text, so they can be tested without a browser.
(function (root) {
  const digits = (s) => String(s ?? "").replace(/\D/g, "");

  /** GS1 check digit, so a random number on the page is not taken for an EAN. */
  function validGtin(code) {
    if (!/^(\d{8}|\d{12,14})$/.test(code)) return false;
    const d = code.split("").map(Number);
    const check = d.pop();
    const sum = d.reverse().reduce((s, n, i) => s + n * (i % 2 === 0 ? 3 : 1), 0);
    return (10 - (sum % 10)) % 10 === check;
  }

  /** "1 234,50", "1.234,50 kr", "129,-", 129.9 → number; anything else → null. */
  function parsePrice(v) {
    if (typeof v === "number") return v > 0 && v < 1e6 ? v : null;
    if (typeof v !== "string") return null;
    let s = v.replace(/kr|nok|,-|\s| /gi, "");
    if (/,\d{1,2}$/.test(s)) s = s.replace(/\./g, "").replace(",", ".");
    else s = s.replace(/,/g, "");
    const n = Number(s);
    return Number.isFinite(n) && n > 0 && n < 1e6 ? n : null;
  }

  function collectProducts(node, out) {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) return node.forEach((n) => collectProducts(n, out));
    const types = [].concat(node["@type"] ?? []);
    if (types.includes("Product") || types.includes("ProductGroup")) out.push(node);
    if (node["@graph"]) collectProducts(node["@graph"], out);
  }

  /** From the page's <script type="application/ld+json"> blocks. */
  function fromJsonLd(texts) {
    const products = [];
    for (const t of texts) {
      try {
        collectProducts(JSON.parse(t), products);
      } catch {
        // A broken block is skipped.
      }
    }
    const p = products[0];
    if (!p) return {};
    const gtin = digits(p.gtin13 ?? p.gtin ?? p.gtin14 ?? p.gtin12 ?? p.gtin8);
    let price = null;
    for (const o of [].concat(p.offers ?? [])) {
      if (o.priceCurrency && o.priceCurrency !== "NOK") continue;
      price = parsePrice(o.price ?? o.lowPrice ?? o.priceSpecification?.price);
      if (price) break;
    }
    return {
      name: typeof p.name === "string" ? p.name.trim() : null,
      gtin: validGtin(gtin) ? gtin : null,
      price,
    };
  }

  const EL = /\bel[\s.\-]*(?:nr|nummer|no)\b\.?\s*:?\s*(\d{2}\s?\d{3}\s?\d{2})(?!\d)/i;
  const NRF = /\bnrf(?:[\s.\-]*(?:nr|nummer|no)\b)?\.?\s*:?\s*(\d{7})(?!\d)/i;
  // «Ean artikkelnr» is Ahlsell's label.
  const EAN = /\b(?:ean|gtin)(?:[\s.\-]*(?:kode|nr|nummer|code|artikkelnr|artikkelnummer))?\.?\s*:?\s*(\d{8}|\d{12,14})(?!\d)/i;

  /** From the visible text: «El.nr: 10 001 04», «NRF-nr 1234567», «EAN 7041234567890». */
  function fromText(text) {
    const el = text.match(EL);
    const nrf = text.match(NRF);
    const ean = text.match(EAN);
    return {
      elNr: el ? digits(el[1]) : null,
      nrfNr: nrf ? nrf[1] : null,
      gtin: ean && validGtin(ean[1]) ? ean[1] : null,
    };
  }

  /**
   * Numbers that only one site labels its own way. Ahlsell shows no «El.nr»:
   * on its electrical products the 7-digit «Artikkelnr» is the EL number.
   */
  function fromSite(host, path, text, scripts = "") {
    const inUrl = elFromUrl(host, path);
    if (inUrl) return { elNr: inUrl };
    if (/(^|\.)ahlsell\.no$/.test(host) && /^\/products\/elektro\//.test(path)) {
      const m = text.match(/\bartikkelnr\b\.?\s*:?\s*(\d{7})(?!\d)/i);
      if (m) return { elNr: m[1] };
    }
    // Onninen keeps the product's own EL number in the page data («electCode»). The
    // text can name other products' EL numbers first (accessories in the description).
    if (/(^|\.)onninen\.no$/.test(host)) {
      const m = String(scripts ?? "").match(/"electCode"\s*:\s*"(\d{7})"/);
      if (m) return { elNr: m[1] };
    }
    return {};
  }

  /**
   * The EL number in the page's address, on the sites that put it there. It is the
   * page's own product; the text can mention other products' EL numbers before it
   * («strekkavlaster … (el.nr. 1241000)» on another product's page).
   * Elektroimportøren: /<slug>/<EL>/Product.html. Berggård: /catalog/product/<slug>-<EL>.
   * Ahlsell: /products/elektro/…/<EL>---<slug>, or …/<EL> at the end.
   */
  function elFromUrl(host, path) {
    const p = String(path ?? "");
    let m = null;
    if (/(^|\.)elektroimportoren\.no$/.test(host)) m = p.match(/\/(\d{7})\/Product\.html$/i);
    else if (/(^|\.)berggardamundsen\.no$/.test(host)) m = p.match(/^\/catalog\/product\/.*-(\d{7})\/?$/);
    else if (/(^|\.)ahlsell\.no$/.test(host)) m = p.match(/^\/products\/elektro\/.*\/(\d{7})(?:---[^/]*)?\/?$/);
    return m ? m[1] : null;
  }

  /**
   * Whether a wholesaler's page shows one product. Their category and search
   * pages list many, and the first number there is not the page's product.
   */
  function isProductPage(host, path) {
    if (/(^|\.)ahlsell\.no$/.test(host)) return path.startsWith("/products/");
    if (/(^|\.)onninen\.no$/.test(host)) return /\/p\/[^/]+\/?$/.test(path);
    if (/(^|\.)elektroimportoren\.no$/.test(host)) return /\/Product\.html$/i.test(path);
    // Solar: …/no-webshop/<category>/<product id>/
    if (/(^|\.)solarnorge\.no$/.test(host)) return /^\/no-webshop\/.+\/\d{6,}\/?$/.test(path);
    return true;
  }

  /**
   * Whether a wholesaler's product is an electrical one. Ahlsell has
   * «/products/elektro/» in the address; Onninen's addresses do not say, but its
   * breadcrumb (Hjem > Elektro > …) links to «/elektro/…». Other sites: yes.
   */
  function isElektro(host, path, breadcrumbLinks) {
    if (/(^|\.)ahlsell\.no$/.test(host)) return path.startsWith("/products/elektro/");
    if (/(^|\.)onninen\.no$/.test(host)) return breadcrumbLinks.some((href) => /^\/elektro\//.test(href ?? ""));
    return true;
  }

  /** The first value found, in the order the sources are given. */
  function merge(...sources) {
    const pick = (k) => sources.map((s) => s?.[k]).find((v) => v != null && v !== "") ?? null;
    return { elNr: pick("elNr"), nrfNr: pick("nrfNr"), gtin: pick("gtin"), name: pick("name"), price: pick("price") };
  }

  root.LMExtract = { digits, validGtin, parsePrice, fromJsonLd, fromText, fromSite, elFromUrl, isProductPage, isElektro, merge };
})(globalThis);
